﻿Imports System.Net
Imports System.Xml
Imports System.IO

Public Class PaymentBatchList

    Private privatedefxmlns As String
    Public Property defxmlns() As String
        Get
            Return privatedefxmlns
        End Get
        Set(ByVal value As String)
            privatedefxmlns = value
        End Set
    End Property
    Private BatchName_Renamed As String = ""
    Public Overridable Property BatchName As String
        Get
            Return BatchName_Renamed
        End Get
        Set(ByVal value As String)
            BatchName_Renamed = value
        End Set
    End Property
    Private BatchID_Renamed As String = ""
    Public Overridable Property BatchID As String
        Get
            Return BatchID_Renamed
        End Get
        Set(ByVal value As String)
            BatchID_Renamed = value
        End Set
    End Property
    Private BatchTotal_Renamed As String = ""
    Public Overridable Property BatchTotal As String
        Get
            Return BatchTotal_Renamed
        End Get
        Set(ByVal value As String)
            BatchTotal_Renamed = value
        End Set
    End Property
    Private Currency_Renamed As String = ""
    Public Overridable Property Currency As String
        Get
            Return Currency_Renamed
        End Get
        Set(ByVal value As String)
            Currency_Renamed = value
        End Set
    End Property
    Private Count_Renamed As String = ""
    Public Overridable Property Count As String
        Get
            Return Count_Renamed
        End Get
        Set(ByVal value As String)
            Count_Renamed = value
        End Set
    End Property
    Private Type_Renamed As String = ""
    Public Overridable Property Type As String
        Get
            Return Type_Renamed
        End Get
        Set(ByVal value As String)
            Type_Renamed = value
        End Set
    End Property
    Private PaymentMethod_Renamed As String = ""
    Public Overridable Property PaymentMethod As String
        Get
            Return PaymentMethod_Renamed
        End Get
        Set(ByVal value As String)
            PaymentMethod_Renamed = value
        End Set
    End Property
    Private Batch_URL_Renamed As String = ""
    Public Overridable Property Batch_URL As String
        Get
            Return Batch_URL_Renamed
        End Get
        Set(ByVal value As String)
            Batch_URL_Renamed = value
        End Set
    End Property

    Public Shared Function getPaymentBatchLists(ByVal uri As String, ByVal token As String) As PaymentBatchListList

        ' Send the request
        Dim response As HttpWebResponse = RequestWrapper.MakeHttpTokenRequest(uri, "GET", "", token)

        ' Return the list of jobs contained within the response
        Return getFromResponse(response)

    End Function

    Private Shared Function getFromResponse(ByVal response As HttpWebResponse) As PaymentBatchListList

        ' Generate a string from the response
        Dim xml As String = Utilities.getStringFromStreamtoString(response.GetResponseStream())

        ' Parse the xml into a list of reorts
        Dim ListsOut As New PaymentBatchListList()
        If (xml = "") Then
            Return Nothing
        End If
        Dim xmlReader As XmlReader = xmlReader.Create(New StringReader(xml))
        ListsOut.parseResponse(xmlReader)

        Return ListsOut

    End Function

End Class

Public Class PaymentBatchListList
    Inherits List(Of PaymentBatchList)

    Private privatedefxmlns As String
    Public Property defxmlns() As String
        Get
            Return privatedefxmlns
        End Get
        Set(ByVal value As String)
            privatedefxmlns = value
        End Set
    End Property

    Public Sub parseResponse(ByVal xmlreader As XmlReader)

        Dim currentEntry As PaymentBatchList = Nothing

        Do While xmlreader.Read()

            If defxmlns = "" Then
                defxmlns = xmlreader.NamespaceURI.ToString
            End If

            Select Case xmlreader.NodeType
                Case XmlNodeType.Element ' The node is an element.
                    If xmlreader.Name.Equals("BatchSummary") AndAlso xmlreader.IsStartElement() Then
                        currentEntry = New PaymentBatchList()
                        currentEntry.defxmlns = xmlreader.NamespaceURI.ToString
                    ElseIf xmlreader.Name.Equals("BatchName") Then
                        xmlreader.Read()
                        currentEntry.BatchName = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("BatchID") Then
                        xmlreader.Read()
                        currentEntry.BatchID = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("BatchTotal") Then
                        xmlreader.Read()
                        currentEntry.BatchTotal = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Currency") Then
                        xmlreader.Read()
                        currentEntry.Currency = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Count") Then
                        xmlreader.Read()
                        currentEntry.Count = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Type") Then
                        xmlreader.Read()
                        currentEntry.Type = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("PaymentMethod") Then
                        xmlreader.Read()
                        currentEntry.PaymentMethod = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Batch-Url") Then
                        xmlreader.Read()
                        currentEntry.Batch_URL = xmlreader.Value
                    End If
                Case XmlNodeType.EndElement 'Reached the end of the element.
                    If xmlreader.Name.Equals("BatchSummary") Then
                        If currentEntry IsNot Nothing Then
                            Add(currentEntry)
                            currentEntry = Nothing
                        End If
                    End If
                Case Else
            End Select
        Loop
    End Sub

End Class
