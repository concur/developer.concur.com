﻿Imports System.Net
Imports System.Xml
Imports System.IO

Public Class PaymentBatchClose

    Private Extract_URL_Renamed As String = ""
    Public Overridable Property Extract_URL As String
        Get
            Return Extract_URL_Renamed
        End Get
        Set(ByVal value As String)
            Extract_URL_Renamed = value
        End Set
    End Property

    Public Shared Function PostPaymentBatchClose(ByVal uri As String, ByVal token As String) As PaymentBatchClose

        ' Send the request
        Dim response As HttpWebResponse = RequestWrapper.MakeHttpTokenRequest(uri, "POST", "", token)

        ' Return the response
        Return getFromResponse(response)

    End Function

    Private Shared Function getFromResponse(ByVal response As HttpWebResponse) As PaymentBatchClose

        ' Generate a string from the response
        Dim xml As String = Utilities.getStringFromStreamtoString(response.GetResponseStream())

        ' Parse the xml 
        Dim PBCOut As New PaymentBatchClose()
        If (xml = "") Then
            Return Nothing
        End If
        Dim xmlReader As XmlReader = xmlReader.Create(New StringReader(xml))
        PBCOut = parseResponse(xmlReader)

        Return PBCOut

    End Function

    Private Shared Function parseResponse(ByVal xmlreader As XmlReader) As PaymentBatchClose

        Dim currentEntry As PaymentBatchClose = Nothing

        Do While xmlreader.Read()
            Select Case xmlreader.NodeType
                Case XmlNodeType.Element ' The node is an element.
                    If xmlreader.Name.Equals("File-Url") AndAlso xmlreader.IsStartElement() Then
                        xmlreader.Read()
                        currentEntry = New PaymentBatchClose
                        currentEntry.Extract_URL = xmlreader.Value
                    End If
                Case Else
            End Select
        Loop

        Return currentEntry

    End Function

End Class
