﻿Imports System.Configuration

Public Class ManagePaymentBatch

    Dim urlPaymentBatchList As String = ConfigurationManager.AppSettings("baseurlPaymentBatchList")


    Public Shared GlbToken As String
    Public Sub New(ByVal token As String)
        GlbToken = token
    End Sub

    Public Function GetPaymentBatchList() As PaymentBatchListList

        Try
            Dim PaymentBatchLists As PaymentBatchListList = PaymentBatchList.getPaymentBatchLists(urlPaymentBatchList, GlbToken)
            If PaymentBatchLists IsNot Nothing Then
                Return PaymentBatchLists
            End If
        Catch ex As Exception

        End Try

        Return Nothing

    End Function

    Public Function POSTPaymentBatchClose(ByVal url As String) As PaymentBatchClose

        Try
            Dim PaymentBatchClosed As PaymentBatchClose = PaymentBatchClose.PostPaymentBatchClose(url + "/close", GlbToken)
            If PaymentBatchClosed IsNot Nothing Then
                Return PaymentBatchClosed
            End If
        Catch ex As Exception

        End Try

        Return Nothing

    End Function

    Public Function GetPaymentBatchFile(ByVal url As String) As PaymentBatchFileReturn

        Try
            Dim PaymentBatchData As PaymentBatchFileReturn = PaymentBatchFile.getPaymentBatchFile(url, GlbToken)
            If PaymentBatchData IsNot Nothing Then
                Return PaymentBatchData
            End If
        Catch ex As Exception

        End Try

        Return Nothing

    End Function

End Class
