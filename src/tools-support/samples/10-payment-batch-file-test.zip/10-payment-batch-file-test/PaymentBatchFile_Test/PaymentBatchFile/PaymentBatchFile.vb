﻿Imports System.Net
Imports System.Xml
Imports System.IO
Imports System.Text

Public Class PaymentBatchFile

    Public Shared Function getPaymentBatchFile(ByVal uri As String, ByVal token As String) As PaymentBatchFileReturn

        ' Send the request
        Dim response As HttpWebResponse = RequestWrapper.MakeHttpTokenRequest(uri, "GET", "", token)

        ' Return the list of jobs contained within the response
        Return getFileFromResponse(response)

    End Function

    Public Shared Function getFileFromResponse(ByVal response As HttpWebResponse) As PaymentBatchFileReturn

        Dim typeout As New PaymentBatchFileReturn

        Dim responseBody As String = Nothing
        If response.ContentType.Equals("text/csv") Then
            Dim sr As New StreamReader(response.GetResponseStream(), Encoding.UTF8)
            typeout.typeStr = "text/csv"
            typeout.strValue = sr.ReadToEnd()
        ElseIf response.ContentType.Equals("application/zip") Then
            Using br As New BinaryReader(response.GetResponseStream())
                typeout.typeStr = "application/zip"
                typeout.strValue = br.ReadString()
            End Using
        Else
            Dim sr As New StreamReader(response.GetResponseStream(), Encoding.UTF8)
            typeout.typeStr = "text/csv"
            typeout.strValue = sr.ReadToEnd()
        End If

        Return typeout

    End Function

End Class

Public Class PaymentBatchFileReturn
    Private typeStr_Renamed As String = ""
    Public Overridable Property typeStr As String
        Get
            Return typeStr_Renamed
        End Get
        Set(ByVal value As String)
            typeStr_Renamed = value
        End Set
    End Property
    Private strValue_Renamed As String = ""
    Public Overridable Property strValue As String
        Get
            Return strValue_Renamed
        End Get
        Set(ByVal value As String)
            strValue_Renamed = value
        End Set
    End Property
End Class

