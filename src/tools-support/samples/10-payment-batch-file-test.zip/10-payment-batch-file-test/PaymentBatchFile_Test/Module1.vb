﻿Module Module1

    Private domain_Renamed As String = ""
    Public Property domain As String
        Get
            Return domain_Renamed
        End Get
        Set(ByVal value As String)
            domain_Renamed = value
        End Set
    End Property
    Private username_Renamed As String = ""
    Public Property username As String
        Get
            Return username_Renamed
        End Get
        Set(ByVal value As String)
            username_Renamed = value
        End Set
    End Property
    Private consumer_Renamed As String = ""
    Public Property consumer As String
        Get
            Return consumer_Renamed
        End Get
        Set(ByVal value As String)
            consumer_Renamed = value
        End Set
    End Property
    Private secKey_Renamed As String = ""
    Public Property secKey As String
        Get
            Return secKey_Renamed
        End Get
        Set(ByVal value As String)
            secKey_Renamed = value
        End Set
    End Property

    Sub Main()

        Dim CONSUMER_KEY As String = "CONSUMER_KEY"
        Dim USER As String = "USER"
        Dim PASSWORD As String = "PASSWORD"
        Dim URL As String = "https://www.concursolutions.com/net2/oauth2/accesstoken.ashx"

        Dim Mgr As New Manager(CONSUMER_KEY, USER, PASSWORD, URL)

        Dim MgrPB As New ManagePaymentBatch(Mgr.tokens.Token.ToString)

        Dim PaymentBatchLists As New PaymentBatchListList
        PaymentBatchLists = MgrPB.GetPaymentBatchList()

        Dim PaymentBatchClosed As New PaymentBatchClose
        PaymentBatchClosed = MgrPB.POSTPaymentBatchClose(PaymentBatchLists.Item(1).Batch_URL.ToString) 'THIS IS IMPORTANT AS THIS ONLY PULLS THE FIRST PAYMENT BATCH.

        Dim PaymentBatchData As New PaymentBatchFileReturn
        PaymentBatchData = MgrPB.GetPaymentBatchFile(PaymentBatchClosed.Extract_URL.ToString)

    End Sub

End Module
