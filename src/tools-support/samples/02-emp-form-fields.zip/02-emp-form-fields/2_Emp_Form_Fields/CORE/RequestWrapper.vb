﻿Imports System
Imports System.IO
Imports System.Net
Imports System.Text
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Linq
Imports System.Security.Cryptography
Imports System.Web
Imports System.Configuration

Public Class RequestWrapper

    Dim consumerKey As String

    Public Sub New(ByVal key As String)
        consumerKey = key
    End Sub

    Public Function MakeHttpRequestBasic(ByVal baseurl As String, ByVal httpMethod As String, ByVal credentials As String) As HttpWebResponse

        Dim authString As String = Convert.ToBase64String(Encoding.Default.GetBytes(credentials))
        Dim request As HttpWebRequest = CType(WebRequest.Create(baseurl), HttpWebRequest)
        request.Headers.Add("Authorization", "Basic " + authString)
        request.Headers.Add("X-ConsumerKey", consumerKey)

        Try
            Return CType(request.GetResponse(), HttpWebResponse)

        Catch ex As WebException
            Console.WriteLine(ex.Message.ToString)
        End Try

        Return Nothing

    End Function

    Public Function MakeHttpTokenRequest(ByVal baseurl As String, ByVal httpMethod As String, ByVal reqdata As String, ByVal token As String) As HttpWebResponse

        Dim request As HttpWebRequest = CType(WebRequest.Create(baseurl), HttpWebRequest)
        request.Headers.Add("Authorization", "OAuth " + token)

        If httpMethod.Equals("POST") Then
            request.Method = "POST"
            Dim reqbody As New StringBuilder()
            reqbody.Append(reqdata)
            Dim data() As Byte = System.Text.Encoding.UTF8.GetBytes(reqbody.ToString())
            request.ContentType = "application/xml; charset=utf-8"
            request.ContentLength = data.Length
            Using newStream As Stream = request.GetRequestStream()
                newStream.Write(data, 0, data.Length)
            End Using
        End If

        Try
            Return CType(request.GetResponse(), HttpWebResponse)

        Catch ex As WebException
            Console.WriteLine(ex.Message.ToString)
        End Try

        Return Nothing

    End Function

End Class
