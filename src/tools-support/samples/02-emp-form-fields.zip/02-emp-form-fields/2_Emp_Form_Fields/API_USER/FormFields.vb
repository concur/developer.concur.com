﻿
Imports System.Xml
Imports System.Net
Imports System.IO

Public Class FormFields

    Private ID_Renamed As String = ""
    Public Overridable Property ID As String
        Get
            Return ID_Renamed
        End Get
        Set(ByVal value As String)
            ID_Renamed = value
        End Set
    End Property
    Private Label_Renamed As String = ""
    Public Overridable Property Label As String
        Get
            Return Label_Renamed
        End Get
        Set(ByVal value As String)
            Label_Renamed = value
        End Set
    End Property
    Private ControlType_Renamed As String = ""
    Public Overridable Property ControlType As String
        Get
            Return ControlType_Renamed
        End Get
        Set(ByVal value As String)
            ControlType_Renamed = value
        End Set
    End Property
    Private DataType_Renamed As String = ""
    Public Overridable Property DataType As String
        Get
            Return DataType_Renamed
        End Get
        Set(ByVal value As String)
            DataType_Renamed = value
        End Set
    End Property
    Private MaxLength_Renamed As String = ""
    Public Overridable Property MaxLength As String
        Get
            Return MaxLength_Renamed
        End Get
        Set(ByVal value As String)
            MaxLength_Renamed = value
        End Set
    End Property
    Private Required_Renamed As String = ""
    Public Overridable Property RequiredBol As String
        Get
            Return Required_Renamed
        End Get
        Set(ByVal value As String)
            Required_Renamed = value
        End Set
    End Property
    Private Cols_Renamed As String = ""
    Public Overridable Property Cols As String
        Get
            Return Cols_Renamed
        End Get
        Set(ByVal value As String)
            Cols_Renamed = value
        End Set
    End Property
    Private Access_Renamed As String = ""
    Public Overridable Property AccessType As String
        Get
            Return Access_Renamed
        End Get
        Set(ByVal value As String)
            Access_Renamed = value
        End Set
    End Property
    Private Width_Renamed As String = ""
    Public Overridable Property WidthChk As String
        Get
            Return Width_Renamed
        End Get
        Set(ByVal value As String)
            Width_Renamed = value
        End Set
    End Property
    Private Custom_Renamed As String = ""
    Public Overridable Property Custom As String
        Get
            Return Custom_Renamed
        End Get
        Set(ByVal value As String)
            Custom_Renamed = value
        End Set
    End Property
    Private Sequence_Renamed As String = ""
    Public Overridable Property Sequence As String
        Get
            Return Sequence_Renamed
        End Get
        Set(ByVal value As String)
            Sequence_Renamed = value
        End Set
    End Property
    Private privatedefxmlns As String
    Public Property defxmlns() As String
        Get
            Return privatedefxmlns
        End Get
        Set(ByVal value As String)
            privatedefxmlns = value
        End Set
    End Property

    Public Shared Function getFormFields(ByVal uri As String, ByVal token As String) As FormFieldsList

        ' Send the request
        Dim response As HttpWebResponse = ManageUsers.HttpWrapper.MakeHttpTokenRequest(uri, "GET", "", token)

        Dim xml As String = Utilities.getStringFromStream(response.GetResponseStream())

        ' Print the response
        'MsgBox(xml.ToString)

        ' Parse the xml into a list
        Dim fields As New FormFieldsList()
        If (xml = "") Then
            Return Nothing
        End If

        Dim xmlReader As XmlReader = xmlReader.Create(New StringReader(xml))
        fields.parseUser(xmlReader)

        Return fields

    End Function

End Class

Public Class FormFieldsList
    Inherits List(Of FormFields)

    Private privatedefxmlns As String
    Public Property defxmlns() As String
        Get
            Return privatedefxmlns
        End Get
        Set(ByVal value As String)
            privatedefxmlns = value
        End Set
    End Property

    Public Sub parseUser(ByVal xmlreader As XmlReader)
        Dim currentDef As FormFields = Nothing

        Do While xmlreader.Read()
            If defxmlns = "" Then
                defxmlns = xmlreader.NamespaceURI.ToString
            End If
            Select Case xmlreader.NodeType

                Case XmlNodeType.Element ' The node is an element.
                    If xmlreader.Name.Equals("FormField") AndAlso xmlreader.IsStartElement() Then
                        currentDef = New FormFields()
                        currentDef.defxmlns = xmlreader.NamespaceURI.ToString

                    ElseIf xmlreader.Name.Equals("Id") Then
                        xmlreader.Read()
                        currentDef.ID = xmlreader.Value

                    ElseIf xmlreader.Name.Equals("Label") Then
                        xmlreader.Read()
                        currentDef.Label = xmlreader.Value

                    ElseIf xmlreader.Name.Equals("ControlType") Then
                        xmlreader.Read()
                        currentDef.ControlType = xmlreader.Value

                    ElseIf xmlreader.Name.Equals("DataType") Then
                        xmlreader.Read()
                        currentDef.DataType = xmlreader.Value

                    ElseIf xmlreader.Name.Equals("MaxLength") Then
                        xmlreader.Read()
                        currentDef.MaxLength = xmlreader.Value

                    ElseIf xmlreader.Name.Equals("Required") Then
                        xmlreader.Read()
                        currentDef.RequiredBol = xmlreader.Value

                    ElseIf xmlreader.Name.Equals("Cols") Then
                        xmlreader.Read()
                        currentDef.Cols = xmlreader.Value

                    ElseIf xmlreader.Name.Equals("Access") Then
                        xmlreader.Read()
                        currentDef.AccessType = xmlreader.Value

                    ElseIf xmlreader.Name.Equals("Width") Then
                        xmlreader.Read()
                        currentDef.WidthChk = xmlreader.Value

                    ElseIf xmlreader.Name.Equals("Custom") Then
                        xmlreader.Read()
                        currentDef.Custom = xmlreader.Value

                    ElseIf xmlreader.Name.Equals("Sequence") Then
                        xmlreader.Read()
                        currentDef.Sequence = xmlreader.Value

                    End If

                Case XmlNodeType.EndElement 'Reached the end of the element.
                    If xmlreader.Name.Equals("FormField") Then
                        If currentDef IsNot Nothing Then
                            Add(currentDef)
                            currentDef = Nothing
                        End If
                    End If

                Case Else
            End Select
        Loop
    End Sub

End Class
