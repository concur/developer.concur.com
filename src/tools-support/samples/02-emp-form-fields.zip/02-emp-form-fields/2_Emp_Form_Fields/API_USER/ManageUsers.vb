﻿Imports System.Configuration
Imports System.Web

Public Class ManageUsers

    Public Shared HttpWrapper As RequestWrapper

    Private tokens_Renamed As OAuth2
    Public Overridable Property tokens As OAuth2
        Get
            Return tokens_Renamed
        End Get
        Set(ByVal value As OAuth2)
            tokens_Renamed = value
        End Set
    End Property

    Public Sub New(ByVal key As String, ByVal user As String, ByVal password As String, ByVal Endpoint As String)
        HttpWrapper = New RequestWrapper(key)
        tokens = New OAuth2
        tokens = OAuth2.GetAccessToken(Endpoint, user, password)
    End Sub

    Public Function getformfields(ByVal Endpoint As String) As FormFieldsList

        Try
            Dim baseField As FormFieldsList = FormFields.getFormFields(Endpoint, tokens.Token.ToString)
            If baseField IsNot Nothing Then
                Return baseField
            End If
        Catch ex As Exception
            Console.WriteLine(ex.Message.ToString)
        End Try

        Return Nothing

    End Function
    
End Class
