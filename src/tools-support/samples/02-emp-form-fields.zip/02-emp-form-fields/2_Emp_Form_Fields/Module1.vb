﻿Module Module1

    Sub Main()
        Dim user As String = "LoginId"
        Dim password As String = "Password"
        Dim key As String = "Consumer Key"

        Dim AuthorizationTokenURL As String = "https://www.concursolutions.com/net2/oauth2/accesstoken.ashx"

        Dim userMgr As New ManageUsers(key, user, password, AuthorizationTokenURL)

        Dim FormFieldsURL As String = "https://www.concursolutions.com/api/user/v1.0/FormFields"

        Dim frmFields As New FormFieldsList
        frmFields = userMgr.getformfields(FormFieldsURL)

        ''Display Purposes
        Console.WriteLine("Required Fields")
        Console.WriteLine("****************************")

        For Each fields As FormFields In frmFields

            If fields.RequiredBol.ToString = "Y" Then

                Console.WriteLine("User Field: " + fields.ID.ToString)
                Console.WriteLine("UI Name: " + fields.Label.ToString)
                Console.WriteLine("****************************")
            End If

        Next

        Console.ReadLine()

    End Sub

End Module
