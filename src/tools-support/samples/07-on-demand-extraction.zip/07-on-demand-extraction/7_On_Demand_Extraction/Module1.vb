﻿Module Module1

    Sub Main()
        Dim user As String = "LoginId"
        Dim password As String = "Password"
        Dim key As String = "Consumer Key"

        Dim AuthorizationTokenURL As String = "https://www.concursolutions.com/net2/oauth2/accesstoken.ashx"

        Dim extMgr As New ManageExtracts(key, user, password, AuthorizationTokenURL)

        Dim ExtractURL As String = "https://www.concursolutions.com/api/expense/extract/v1.0/"

        Dim defLst As New DefinitionList
        defLst = extMgr.GetExtractDefinitionList(ExtractURL)

        Dim job As New ProcessJob
        job = extMgr.PostExtractJobRequest(defLst.Item(2))

        Dim stat As New ProcessJob
        stat = extMgr.GetExtractJobStatus(job)

        Console.WriteLine("Job: " + job.Id.ToString)
        Console.ReadLine()

        If stat IsNot Nothing Then
            Do While stat.Status.ToString <> "Completed"
                stat = extMgr.GetExtractJobStatus(job)
            Loop
        End If

        Console.WriteLine("Status: " + stat.Status.ToString)
        Console.ReadLine()

        Dim fileData As New returntype
        If stat.FileLink <> Nothing Then
            fileData = extMgr.GetExtractJobFile(stat)
        End If

        Console.WriteLine(fileData.strValue.ToString)
        Console.ReadLine()

    End Sub

End Module
