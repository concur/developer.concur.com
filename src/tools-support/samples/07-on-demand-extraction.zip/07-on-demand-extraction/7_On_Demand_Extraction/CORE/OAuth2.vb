﻿Imports System.Xml
Imports System.IO
Imports System.Net

Public Class OAuth2

    Private Expiration_Date_Renamed As String = ""
    Public Overridable Property Expiration_Date As String
        Get
            Return Expiration_Date_Renamed
        End Get
        Set(ByVal value As String)
            Expiration_Date_Renamed = value
        End Set
    End Property
    Private Token_Renamed As String = ""
    Public Overridable Property Token As String
        Get
            Return Token_Renamed
        End Get
        Set(ByVal value As String)
            Token_Renamed = value
        End Set
    End Property

    Public Shared Function GetAccessToken(ByVal uri As String, ByVal user As String, ByVal password As String) As OAuth2

        ' Send the request
        Dim response As HttpWebResponse = ManageExtracts.HttpWrapper.MakeHttpRequestBasic(uri, "GET", user + ":" + password)

        ' Return the list of jobs contained within the response
        Return getReportFromResponse(response)

    End Function

    Private Shared Function getReportFromResponse(ByVal response As HttpWebResponse) As OAuth2

        ' Generate a string from the response
        Dim xml As String = Utilities.getStringFromStream(response.GetResponseStream())

        ' Parse the xml into a list of reorts
        Dim RespOut As New OAuth2()
        If (xml = "") Then
            Return Nothing
        End If
        Dim xmlReader As XmlReader = xmlReader.Create(New StringReader(xml))
        RespOut = parseReport(xmlReader)

        Return RespOut

    End Function

    Public Shared Function parseReport(ByVal xmlreader As XmlReader)

        Dim currentReport As OAuth2 = Nothing

        Do While xmlreader.Read()

            Select Case xmlreader.NodeType
                Case XmlNodeType.Element ' The node is an element.
                    If xmlreader.Name.Equals("Access_Token") AndAlso xmlreader.IsStartElement() Then
                        currentReport = New OAuth2
                    ElseIf xmlreader.Name.Equals("Token") Then
                        xmlreader.Read()
                        currentReport.Token = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Expiration_date") Then
                        xmlreader.Read()
                        currentReport.Expiration_Date = xmlreader.Value
                    End If
                Case Else
            End Select
        Loop

        Return currentReport
    End Function

End Class

