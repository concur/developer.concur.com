﻿Imports System.Xml
Imports System.Configuration

Public Class ManageExtracts
    Public Shared HttpWrapper As RequestWrapper

    Private tokens_Renamed As OAuth2
    Public Overridable Property tokens As OAuth2
        Get
            Return tokens_Renamed
        End Get
        Set(ByVal value As OAuth2)
            tokens_Renamed = value
        End Set
    End Property

    Public Sub New(ByVal key As String, ByVal user As String, ByVal password As String, ByVal Endpoint As String)
        HttpWrapper = New RequestWrapper(key)
        tokens = New OAuth2
        tokens = OAuth2.GetAccessToken(Endpoint, user, password)
    End Sub


    Public Function GetExtractDefinitionList(ByVal Endpoint As String) As DefinitionList

        Try
            ' Get list of definitions
            Dim defList As DefinitionList = Definition.getDefinitions(Endpoint, tokens.Token.ToString)

            If defList Is Nothing Then
                Return Nothing
            End If

            Return defList

        Catch ex As Exception
            Console.WriteLine(ex.Message.ToString)
        End Try

        Return Nothing

    End Function

    Public Function GetExtractDefinitionDetails(ByVal def As Definition) As Definition

        Try
            ' Get list of definitions
            Dim definition As Definition = definition.getDefinition(def.Id.ToString, tokens.Token.ToString)

            If definition Is Nothing Then
                Return Nothing
            End If

            Return definition

        Catch ex As Exception
            Console.WriteLine(ex.Message.ToString)
        End Try

        Return Nothing

    End Function

    Public Function PostExtractJobRequest(ByVal def As Definition) As ProcessJob

        Try
            Dim data As String = Definition.create(def)

            Dim job As ProcessJob = ProcessJob.createJob(def.JobLink.ToString, data, tokens.Token.ToString)

            If job Is Nothing Then
                Return Nothing
            End If

            Return job

        Catch ex As Exception
            Console.WriteLine(ex.Message.ToString)
        End Try

        Return Nothing

    End Function

    Public Function GetExtractJobList(ByVal def As Definition) As JobList

        Try
            Dim job As JobList = ProcessJob.getJobs(def.JobLink.ToString, tokens.Token.ToString)

            If job Is Nothing Then
                Return Nothing
            End If

            Return job

        Catch ex As Exception
            Console.WriteLine(ex.Message.ToString)
        End Try

        Return Nothing

    End Function

    Public Function GetExtractJobDetails(ByVal def As Definition) As ProcessJob

        Try
            Dim job As ProcessJob = ProcessJob.getJob(def.JobLink.ToString, tokens.Token.ToString)

            If job Is Nothing Then
                Return Nothing
            End If

            Return job

        Catch ex As Exception
            Console.WriteLine(ex.Message.ToString)
        End Try

        Return Nothing

    End Function

    Public Function GetExtractJobStatus(ByVal jobin As ProcessJob) As ProcessJob

        Try
            Dim job As ProcessJob = ProcessJob.getJob(jobin.StatusLink.ToString, tokens.Token.ToString)

            If job Is Nothing Then
                Return Nothing
            End If

            Return job

        Catch ex As Exception
            Console.WriteLine(ex.Message.ToString)
        End Try

        Return Nothing

    End Function

    Public Function GetExtractJobFile(ByVal jobin As ProcessJob) As returntype

        Try
            Dim file As returntype = ProcessJob.getFile(jobin.FileLink.ToString, tokens.Token.ToString)

            If file Is Nothing Then
                Return Nothing
            End If

            Return file

        Catch ex As Exception
            Console.WriteLine(ex.Message.ToString)
        End Try

        Return Nothing

    End Function

End Class
