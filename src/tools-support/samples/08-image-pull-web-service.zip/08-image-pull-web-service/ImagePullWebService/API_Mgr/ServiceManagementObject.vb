﻿Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Linq
Imports System.Net
Imports System.Text
Imports System.Xml

Public Class ServiceManagementObject

    Public Shared HttpWrapper As RequestWrapper

    Private tokens_Renamed As OAuth2

    Public Overridable Property tokens As OAuth2

        Get
            Return tokens_Renamed
        End Get
        Set(ByVal value As OAuth2)
            tokens_Renamed = value
        End Set

    End Property

    Private privateId As New List(Of String)

    Public Property Id() As List(Of String)

        Get
            Return privateId
        End Get
        Set(ByVal value As List(Of String))
            privateId = value
        End Set

    End Property

    Private imageBytes As New List(Of String)
    Public Property Image() As List(Of String)

        Get
            Return imageBytes
        End Get
        Set(ByVal value As List(Of String))
            imageBytes = value
        End Set

    End Property

    Public Sub New(ByVal uri As String, ByVal token As String)

        Dim response As HttpWebResponse = HttpWrapper.MakeHttpTokenRequest(uri, "GET", "", token)
        Dim xml As String = Utilities.getStringFromStream(response.GetResponseStream())
        Dim xmlReader As XmlReader = xmlReader.Create(New StringReader(xml))

        Do While xmlReader.Read()

            Select Case xmlReader.NodeType

                Case XmlNodeType.Element

                    If xmlReader.Name.Equals("Url") Then
                        xmlReader.Read()
                        imageBytes.Add(xmlReader.Value.ToString)

                    ElseIf xmlReader.Name.Equals("ID") Then
                        xmlReader.Read()
                        privateId.Add(xmlReader.Value.ToString)

                    End If

                Case Else

            End Select

        Loop

    End Sub

    Public Sub New(ByVal key As String, ByVal user As String, ByVal password As String, ByVal Endpoint As String)

        HttpWrapper = New RequestWrapper(key)
        tokens = New OAuth2
        tokens = OAuth2.GetAccessToken(Endpoint, user, password)

    End Sub

End Class
