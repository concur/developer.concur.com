﻿Imports System.Net

Module Module1

    Sub Main()

        'THERE ARE TODO'S AT EACH LOCATION YOU HAVE TO CHANGE SOMETHING IN ORDER TO RUN THIS PROJECT

        'TODO: change the userId, userPassword, consumerKey to that which was sent to you by concur web services
        Dim userId As String = "USER"
        Dim userPassword As String = "PASSWORD"
        Dim consumerKey As String = "CONSUMER"


        'TODO: comment out the enviornment that is NOT the one you are trying to work with

        'PRODUCTION
        'Dim oAuthURL As String = "https://www.concursolutions.com/net2/oauth2/accesstoken.ashx"
        'Dim reportURL As String = "https://www.concursolutions.com/api/v3.0/expense/reportdigests?user=ALL&hasImages=True"
        'Dim imageURL As String = "https://www.concursolutions.com/api/image/v1.0/report/"

        'IMPLEMENTATION
        Dim oAuthURL As String = "https://implementation.concursolutions.com/net2/oauth2/accesstoken.ashx"
        Dim reportURL As String = "https://implementation.concursolutions.com/api/v3.0/expense/reports?user=ALL&hasImages=True"
        Dim imageURL As String = "https://implementation.concursolutions.com/api/image/v1.0/report/"

        Dim tokenManager As New ServiceManagementObject(consumerKey, userId, userPassword, oAuthURL)
        Dim reportResponseObj As New ServiceManagementObject(reportURL, tokenManager.tokens.Token.ToString)

        Console.WriteLine("Authorization Token: " + tokenManager.tokens.Token.ToString + Environment.NewLine)

        For Each item In reportResponseObj.Id()

            Console.WriteLine("Report ID: " + item.ToString + Environment.NewLine)

            Dim imageResponseObj As New ServiceManagementObject((imageURL + item), tokenManager.tokens.Token.ToString)

            For Each image In imageResponseObj.Image

                Console.WriteLine("Image URL: " + image + Environment.NewLine)

                Dim Client As New WebClient

                'TODO: change file path to one that exsits on your machine
                Client.DownloadFile(image, "C:\Images\" + item.ToString + ".pdf")

                Client.Dispose()

            Next

        Next

        Console.ReadLine()

    End Sub

End Module
