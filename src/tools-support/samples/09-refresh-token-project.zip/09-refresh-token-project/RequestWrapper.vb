﻿Imports System
Imports System.IO
Imports System.Net
Imports System.Text
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Linq
Imports System.Security.Cryptography
Imports System.Web
Imports System.Configuration

Public Class RequestWrapper

    Public Shared Function MakeHttpRequestCalloutBasic(ByVal baseurl As String, ByVal httpMethod As String, ByVal credentials As String, ByVal reqdata As String) As HttpWebResponse
        Dim authString As String = Convert.ToBase64String(Encoding.Default.GetBytes(credentials))
        Dim request As HttpWebRequest = CType(WebRequest.Create(baseurl), HttpWebRequest)
        request.Headers.Add("Authorization", "Basic " + authString)
        If httpMethod.Equals("POST") Then
            request.Method = httpMethod.ToString()
            Dim reqbody As New StringBuilder()
            reqbody.Append(reqdata)
            Dim data() As Byte = System.Text.Encoding.UTF8.GetBytes(reqbody.ToString())
            request.ContentType = "application/xml; charset=utf-8"
            request.ContentLength = data.Length
            Using newStream As Stream = request.GetRequestStream()
                newStream.Write(data, 0, data.Length)
            End Using
        End If
        Try
            Return CType(request.GetResponse(), HttpWebResponse)
        Catch ex As WebException
            Dim sb As New System.Text.StringBuilder()
            sb.Append(ex.Message.ToString + Environment.NewLine)
            If ex.Response IsNot Nothing Then
                If ex.Response.ContentLength <> 0 Then
                    Using stream = ex.Response.GetResponseStream()
                        Using reader = New StreamReader(stream)
                            sb.Append(reader.ReadToEnd())
                            Throw New System.Exception(sb.ToString())
                        End Using
                    End Using
                End If
                Throw New System.Exception(ex.Message.ToString)
            End If
            Throw New System.Exception(ex.Message.ToString)
        End Try
        Return Nothing
    End Function

    Public Shared Function MakeHttpRequestBasic(ByVal baseurl As String, ByVal httpMethod As String, ByVal credentials As String, ByVal consumerKey As String) As HttpWebResponse
        Dim authString As String = Convert.ToBase64String(Encoding.Default.GetBytes(credentials))
        Dim request As HttpWebRequest = CType(WebRequest.Create(baseurl), HttpWebRequest)
        request.Headers.Add("Authorization", "Basic " + authString)
        request.Headers.Add("X-ConsumerKey", consumerKey)
        Try
            Return CType(request.GetResponse(), HttpWebResponse)
        Catch ex As WebException
            Dim sb As New System.Text.StringBuilder()
            sb.Append(ex.Message.ToString + Environment.NewLine)
            If ex.Response IsNot Nothing Then
                If ex.Response.ContentLength <> 0 Then
                    Using stream = ex.Response.GetResponseStream()
                        Using reader = New StreamReader(stream)
                            sb.Append(reader.ReadToEnd())
                            Throw New System.Exception(sb.ToString())
                        End Using
                    End Using
                End If
                Throw New System.Exception(ex.Message.ToString)
            End If
            Throw New System.Exception(ex.Message.ToString)
        End Try
        Return Nothing
    End Function

    Public Shared Function MakeHttpTokenRequest(ByVal baseurl As String, ByVal httpMethod As String, ByVal reqdata As String, ByVal token As String) As HttpWebResponse
        Dim request As HttpWebRequest = CType(WebRequest.Create(baseurl), HttpWebRequest)
        request.Headers.Add("Authorization", "OAuth " + token)
        If httpMethod.Equals("POST") Or httpMethod.Equals("PUT") Or httpMethod.Equals("DELETE") Then
            request.Method = httpMethod.ToString()
            Dim reqbody As New StringBuilder()
            reqbody.Append(reqdata)
            Dim data() As Byte = System.Text.Encoding.UTF8.GetBytes(reqbody.ToString())
            request.ContentType = "application/xml; charset=utf-8"
            request.ContentLength = data.Length
            Using newStream As Stream = request.GetRequestStream()
                newStream.Write(data, 0, data.Length)
            End Using
        End If
        Try
            Return CType(request.GetResponse(), HttpWebResponse)
        Catch ex As WebException
            Dim sb As New System.Text.StringBuilder()
            sb.Append(ex.Message.ToString + Environment.NewLine)
            If ex.Response IsNot Nothing Then
                If ex.Response.ContentLength <> 0 Then
                    Using stream = ex.Response.GetResponseStream()
                        Using reader = New StreamReader(stream)
                            sb.Append(reader.ReadToEnd())
                            Throw New System.Exception(sb.ToString())
                        End Using
                    End Using
                End If
                Throw New System.Exception(ex.Message.ToString)
            End If
            Throw New System.Exception(ex.Message.ToString)
        End Try

        Return Nothing
    End Function
End Class
