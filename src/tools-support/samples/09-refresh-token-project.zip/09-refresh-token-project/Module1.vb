﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Xml

Module Module1

    Sub Main()
        Dim CONSUMER_KEY As String = "CONSUMER_KEY"
        Dim REFRESH_TOKEN As String = "REFRESH_TOKEN"
        Dim ACCESS_TOKEN As String = "ACCESS_TOKEN"
        Dim SECRET_KEY As String = "SECRET_KEY"

        Try
            Dim uri As String = "https://implementation.concursolutions.com/net2/oauth2/getaccesstoken.ashx" + "?refresh_token=" + REFRESH_TOKEN + "&client_id=" + CONSUMER_KEY + "&client_secret=" + SECRET_KEY
            Dim response As HttpWebResponse = RequestWrapper.MakeHttpTokenRequest(uri, "POST", "", ACCESS_TOKEN)
            Console.Write(getResponseContentResults(response))
            Console.ReadKey()
        Catch ex As Exception
            Console.Write(ex.Message)
            Console.ReadKey()
        End Try
    End Sub

    Private Function getResponseContentResults(ByVal response As HttpWebResponse) As String
        Dim sb As New System.Text.StringBuilder()
        Dim statCode As Integer = System.Convert.ToInt32(response.StatusCode)
        sb.Append("HTTP Status:" + response.StatusCode.ToString() + Environment.NewLine())
        sb.Append("HTTP Status Code:" + statCode.ToString() + Environment.NewLine())
        sb.Append("HTTP Method:" + response.Method.ToString() + Environment.NewLine())
        sb.Append("Content Type:" + response.ContentType.ToString() + Environment.NewLine())
        sb.Append("Content Length:" + response.ContentLength.ToString() + Environment.NewLine())

        If (statCode.ToString().Equals("200")) Then
            sb.Append(Environment.NewLine() + "TOKEN WAS SUCCESSFULLY REFRESHED" + Environment.NewLine())
        Else
            sb.Append(Environment.NewLine() + "FAILURE" + Environment.NewLine())
        End If

        If (response.ContentLength > 0) And (response.ContentType.Contains("application/xml")) Then
            Dim xml As String = getStringFromStreamtoString(response.GetResponseStream())
            sb.Append(Environment.NewLine() + xml + Environment.NewLine())
        ElseIf response.ContentLength > 0 Then
            Dim content As String = getStringFromStream(response.GetResponseStream())
            sb.Append(Environment.NewLine() + content + Environment.NewLine())
        End If
        Return sb.ToString()
    End Function

    Private Function getStringFromStream(ByVal stream As Stream) As String
        Dim toReturn As String = ""
        Using reader = New StreamReader(stream, Encoding.UTF8)
            toReturn = reader.ReadToEnd()
            Return toReturn
        End Using
    End Function

    Private Function getStringFromStreamtoString(ByVal stream As Stream) As String
        Dim strBuilder As New StringBuilder(10000)
        Dim writer As XmlWriter = XmlWriter.Create(strBuilder, getWriterSettings)
        Dim doc As New XDocument(New XDeclaration("1.0", "UTF-8", "yes"))
        doc = XDocument.Load(stream)
        doc.WriteTo(writer)
        Return doc.ToString()
    End Function

    Private Function getWriterSettings() As XmlWriterSettings
        Dim writerSettings As New XmlWriterSettings()
        writerSettings.Indent = True
        writerSettings.NewLineOnAttributes = True
        Return writerSettings
    End Function
End Module
