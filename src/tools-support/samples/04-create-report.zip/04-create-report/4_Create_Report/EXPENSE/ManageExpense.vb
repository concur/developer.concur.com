﻿Imports System.Configuration


Public Class ManageExpense
    Public Shared HttpWrapper As RequestWrapper

    Private tokens_Renamed As OAuth2
    Public Overridable Property tokens As OAuth2
        Get
            Return tokens_Renamed
        End Get
        Set(ByVal value As OAuth2)
            tokens_Renamed = value
        End Set
    End Property

    Public Sub New(ByVal key As String, ByVal user As String, ByVal password As String, ByVal Endpoint As String)
        HttpWrapper = New RequestWrapper(key)
        tokens = New OAuth2
        tokens = OAuth2.GetAccessToken(Endpoint, user, password)
    End Sub

    Public Function GetReportDetails(ByVal Endpoint As String) As ReportDetails

        Try
            Dim rptList As New ReportDetailList
            If Endpoint <> Nothing Then
                rptList = ReportDetails.getReportDetail(Endpoint, tokens.Token.ToString)
            End If
            If rptList IsNot Nothing Then
                Return rptList.Item(0)
            End If
        Catch ex As Exception
            'MsgBox("Exception: " + ex.Message.ToString)
        End Try

        Return Nothing

    End Function

   
    Public Function PostExpenseReportHearderBatch(ByVal Data As ExpenseReportHeader, ByVal Endpoint As String) As ExpenseReportStatus

        Try

            Dim ReportStatus As ExpenseReportStatus = ExpenseReportHeader.batchReportHeader(Endpoint, Data, tokens.Token.ToString)

            If ReportStatus Is Nothing Then
                Return Nothing
            End If

            Return ReportStatus

        Catch ex As Exception
            ' MsgBox("Exception: " + ex.Message.ToString)
        End Try

        Return Nothing

    End Function

End Class
