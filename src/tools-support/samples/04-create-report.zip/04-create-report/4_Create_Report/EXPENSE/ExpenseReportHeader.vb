﻿Imports System.Net
Imports System.Xml
Imports System.IO

Public Class ExpenseReportHeader
    Private LangCode_Renamed As String = ""
    Public Overridable Property LangCode As String
        Get
            Return LangCode_Renamed
        End Get
        Set(ByVal value As String)
            LangCode_Renamed = value
        End Set
    End Property
    Private Index_Renamed As String = ""
    Public Overridable Property Index As String
        Get
            Return Index_Renamed
        End Get
        Set(ByVal value As String)
            Index_Renamed = value
        End Set
    End Property
    Private LoginId_Renamed As String = ""
    Public Overridable Property LoginId As String
        Get
            Return LoginId_Renamed
        End Get
        Set(ByVal value As String)
            LoginId_Renamed = value
        End Set
    End Property
    Private Name_Renamed As String = ""
    Public Overridable Property Name As String
        Get
            Return Name_Renamed
        End Get
        Set(ByVal value As String)
            Name_Renamed = value
        End Set
    End Property
    Private Purpose_Renamed As String = ""
    Public Overridable Property Purpose As String
        Get
            Return Purpose_Renamed
        End Get
        Set(ByVal value As String)
            Purpose_Renamed = value
        End Set
    End Property
    Private Role_Renamed As String = ""
    Public Overridable Property Role As String
        Get
            Return Role_Renamed
        End Get
        Set(ByVal value As String)
            Role_Renamed = value
        End Set
    End Property
    Private Comment_Renamed As String = ""
    Public Overridable Property Comment As String
        Get
            Return Comment_Renamed
        End Get
        Set(ByVal value As String)
            Comment_Renamed = value
        End Set
    End Property
    Private UserDefinedDate_Renamed As String = ""
    Public Overridable Property UserDefinedDate As String
        Get
            Return UserDefinedDate_Renamed
        End Get
        Set(ByVal value As String)
            UserDefinedDate_Renamed = value
        End Set
    End Property
    Private Custom1_Renamed As String = ""
    Public Overridable Property Custom1 As String
        Get
            Return Custom1_Renamed
        End Get
        Set(ByVal value As String)
            Custom1_Renamed = value
        End Set
    End Property
    Private Custom2_Renamed As String = ""
    Public Overridable Property Custom2 As String
        Get
            Return Custom2_Renamed
        End Get
        Set(ByVal value As String)
            Custom2_Renamed = value
        End Set
    End Property
    Private Custom3_Renamed As String = ""
    Public Overridable Property Custom3 As String
        Get
            Return Custom3_Renamed
        End Get
        Set(ByVal value As String)
            Custom3_Renamed = value
        End Set
    End Property
    Private Custom4_Renamed As String = ""
    Public Overridable Property Custom4 As String
        Get
            Return Custom4_Renamed
        End Get
        Set(ByVal value As String)
            Custom4_Renamed = value
        End Set
    End Property
    Private Custom5_Renamed As String = ""
    Public Overridable Property Custom5 As String
        Get
            Return Custom5_Renamed
        End Get
        Set(ByVal value As String)
            Custom5_Renamed = value
        End Set
    End Property
    Private Custom6_Renamed As String = ""
    Public Overridable Property Custom6 As String
        Get
            Return Custom6_Renamed
        End Get
        Set(ByVal value As String)
            Custom6_Renamed = value
        End Set
    End Property
    Private Custom7_Renamed As String = ""
    Public Overridable Property Custom7 As String
        Get
            Return Custom7_Renamed
        End Get
        Set(ByVal value As String)
            Custom7_Renamed = value
        End Set
    End Property
    Private Custom8_Renamed As String = ""
    Public Overridable Property Custom8 As String
        Get
            Return Custom8_Renamed
        End Get
        Set(ByVal value As String)
            Custom8_Renamed = value
        End Set
    End Property
    Private Custom9_Renamed As String = ""
    Public Overridable Property Custom9 As String
        Get
            Return Custom9_Renamed
        End Get
        Set(ByVal value As String)
            Custom9_Renamed = value
        End Set
    End Property
    Private Custom10_Renamed As String = ""
    Public Overridable Property Custom10 As String
        Get
            Return Custom10_Renamed
        End Get
        Set(ByVal value As String)
            Custom10_Renamed = value
        End Set
    End Property
    Private Custom11_Renamed As String = ""
    Public Overridable Property Custom11 As String
        Get
            Return Custom11_Renamed
        End Get
        Set(ByVal value As String)
            Custom11_Renamed = value
        End Set
    End Property
    Private Custom12_Renamed As String = ""
    Public Overridable Property Custom12 As String
        Get
            Return Custom12_Renamed
        End Get
        Set(ByVal value As String)
            Custom12_Renamed = value
        End Set
    End Property
    Private Custom13_Renamed As String = ""
    Public Overridable Property Custom13 As String
        Get
            Return Custom13_Renamed
        End Get
        Set(ByVal value As String)
            Custom13_Renamed = value
        End Set
    End Property
    Private Custom14_Renamed As String = ""
    Public Overridable Property Custom14 As String
        Get
            Return Custom14_Renamed
        End Get
        Set(ByVal value As String)
            Custom14_Renamed = value
        End Set
    End Property
    Private Custom15_Renamed As String = ""
    Public Overridable Property Custom15 As String
        Get
            Return Custom15_Renamed
        End Get
        Set(ByVal value As String)
            Custom15_Renamed = value
        End Set
    End Property
    Private Custom16_Renamed As String = ""
    Public Overridable Property Custom16 As String
        Get
            Return Custom16_Renamed
        End Get
        Set(ByVal value As String)
            Custom16_Renamed = value
        End Set
    End Property
    Private Custom17_Renamed As String = ""
    Public Overridable Property Custom17 As String
        Get
            Return Custom17_Renamed
        End Get
        Set(ByVal value As String)
            Custom17_Renamed = value
        End Set
    End Property
    Private Custom18_Renamed As String = ""
    Public Overridable Property Custom18 As String
        Get
            Return Custom18_Renamed
        End Get
        Set(ByVal value As String)
            Custom18_Renamed = value
        End Set
    End Property
    Private Custom19_Renamed As String = ""
    Public Overridable Property Custom19 As String
        Get
            Return Custom19_Renamed
        End Get
        Set(ByVal value As String)
            Custom19_Renamed = value
        End Set
    End Property
    Private Custom20_Renamed As String = ""
    Public Overridable Property Custom20 As String
        Get
            Return Custom20_Renamed
        End Get
        Set(ByVal value As String)
            Custom20_Renamed = value
        End Set
    End Property
    Private OrgUnit1_Renamed As String = ""
    Public Overridable Property OrgUnit1 As String
        Get
            Return OrgUnit1_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit1_Renamed = value
        End Set
    End Property
    Private OrgUnit2_Renamed As String = ""
    Public Overridable Property OrgUnit2 As String
        Get
            Return OrgUnit2_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit2_Renamed = value
        End Set
    End Property
    Private OrgUnit3_Renamed As String = ""
    Public Overridable Property OrgUnit3 As String
        Get
            Return OrgUnit3_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit3_Renamed = value
        End Set
    End Property
    Private OrgUnit4_Renamed As String = ""
    Public Overridable Property OrgUnit4 As String
        Get
            Return OrgUnit4_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit4_Renamed = value
        End Set
    End Property
    Private OrgUnit5_Renamed As String = ""
    Public Overridable Property OrgUnit5 As String
        Get
            Return OrgUnit5_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit5_Renamed = value
        End Set
    End Property
    Private OrgUnit6_Renamed As String = ""
    Public Overridable Property OrgUnit6 As String
        Get
            Return OrgUnit6_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit6_Renamed = value
        End Set
    End Property
    Private privatedefxmlns As String
    Public Property defxmlns() As String
        Get
            Return privatedefxmlns
        End Get
        Set(ByVal value As String)
            privatedefxmlns = value
        End Set
    End Property

    Public Shared Function batchReportHeader(ByVal uri As String, ByVal expHeader As ExpenseReportHeader, ByVal token As String) As ExpenseReportStatus

        Dim xmldata As String = createbatch(expHeader)
        ' Send the request
        Dim response As HttpWebResponse = ManageExpense.HttpWrapper.MakeHttpTokenRequest(uri, "POST", xmldata, token)

        ' Return the response
        Return getReportFromResponse(response)

    End Function

    Private Shared Function getReportFromResponse(ByVal response As HttpWebResponse) As ExpenseReportStatus

        ' Generate a string from the response
        Dim xml As String = Utilities.getStringFromStream(response.GetResponseStream())

        ' Parse the xml 
        Dim RespOut As New ExpenseReportStatus()
        If (xml = "") Then
            Return Nothing
        End If
        Dim xmlReader As XmlReader = xmlReader.Create(New StringReader(xml))
        RespOut = parseReport(xmlReader)

        Return RespOut

    End Function

    Public Shared Function parseReport(ByVal xmlreader As XmlReader)

        Dim currentReport As ExpenseReportStatus = Nothing

        Do While xmlreader.Read()

            Select Case xmlreader.NodeType
                Case XmlNodeType.Element ' The node is an element.
                    If xmlreader.Name.Equals("ReportStatus") AndAlso xmlreader.IsStartElement() Then
                        currentReport = New ExpenseReportStatus
                        currentReport.defxmlns = xmlreader.NamespaceURI.ToString
                    ElseIf xmlreader.Name.Equals("Status") Then
                        xmlreader.Read()
                        currentReport.Status = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Report-Details-Url") Then
                        xmlreader.Read()
                        currentReport.ReportDetailsUrl = xmlreader.Value
                    End If
                Case Else
            End Select
        Loop

        Return currentReport
    End Function

    Public Shared Function createbatch(ByVal rptHdr As ExpenseReportHeader) As String

        'create xml
        Dim response As New XmlDocument

        Dim root As XmlElement = response.CreateElement("batch")

        'set attributes
        root.SetAttribute("xmlns", rptHdr.defxmlns.ToString)
        response.AppendChild(root)

        Dim newelement As XmlElement = UsersSerialize(response, rptHdr)
        root.AppendChild(newelement)

        Return response.InnerXml.ToString

    End Function

    Private Shared Function UsersSerialize(ByVal xml As XmlDocument, ByVal data As ExpenseReportHeader) As XmlElement
        Dim appendelement As XmlElement = xml.CreateElement("Report")

        append(xml, appendelement, "Index", data.Index)
        append(xml, appendelement, "LangCode", data.LangCode)
        append(xml, appendelement, "LoginId", data.LoginId)
        append(xml, appendelement, "Name", data.Name)
        append(xml, appendelement, "Purpose", data.Purpose)
        append(xml, appendelement, "Role", data.Role)
        append(xml, appendelement, "Comment", data.Comment)
        append(xml, appendelement, "OrgUnit1", data.OrgUnit1)
        append(xml, appendelement, "OrgUnit2", data.OrgUnit2)
        append(xml, appendelement, "OrgUnit3", data.OrgUnit3)
        append(xml, appendelement, "OrgUnit4", data.OrgUnit4)
        append(xml, appendelement, "OrgUnit5", data.OrgUnit5)
        append(xml, appendelement, "OrgUnit6", data.OrgUnit6)
        append(xml, appendelement, "Custom1", data.Custom1)
        append(xml, appendelement, "Custom2", data.Custom2)
        append(xml, appendelement, "Custom3", data.Custom3)
        append(xml, appendelement, "Custom4", data.Custom4)
        append(xml, appendelement, "Custom5", data.Custom5)
        append(xml, appendelement, "Custom6", data.Custom6)
        append(xml, appendelement, "Custom7", data.Custom7)
        append(xml, appendelement, "Custom8", data.Custom8)
        append(xml, appendelement, "Custom9", data.Custom9)
        append(xml, appendelement, "Custom10", data.Custom10)
        append(xml, appendelement, "Custom11", data.Custom11)
        append(xml, appendelement, "Custom12", data.Custom12)
        append(xml, appendelement, "Custom13", data.Custom13)
        append(xml, appendelement, "Custom14", data.Custom14)
        append(xml, appendelement, "Custom15", data.Custom15)
        append(xml, appendelement, "Custom16", data.Custom16)
        append(xml, appendelement, "Custom17", data.Custom17)
        append(xml, appendelement, "Custom18", data.Custom18)
        append(xml, appendelement, "Custom19", data.Custom19)
        append(xml, appendelement, "Custom20", data.Custom20)
        append(xml, appendelement, "UserDefinedDate", data.UserDefinedDate)
        Return appendelement

    End Function

    Private Shared Sub append(ByVal xml As XmlDocument, ByVal parent As XmlElement, ByVal tagName As String, ByVal value As String)
        Dim node As XmlElement

        If (value IsNot Nothing AndAlso value IsNot "") Then
            node = xml.CreateElement(tagName)
            node.InnerText = value.ToString()
            parent.AppendChild(node)
        End If

    End Sub

End Class

Public Class ExpenseReportStatus

    Private Index_Renamed As String = ""
    Public Overridable Property Index As String
        Get
            Return Index_Renamed
        End Get
        Set(ByVal value As String)
            Index_Renamed = value
        End Set
    End Property
    Private Status_Renamed As String = ""
    Public Overridable Property Status As String
        Get
            Return Status_Renamed
        End Get
        Set(ByVal value As String)
            Status_Renamed = value
        End Set
    End Property
    Private ReportDetailsUrl_Renamed As String = ""
    Public Overridable Property ReportDetailsUrl As String
        Get
            Return ReportDetailsUrl_Renamed
        End Get
        Set(ByVal value As String)
            ReportDetailsUrl_Renamed = value
        End Set
    End Property
    Private privatedefxmlns As String
    Public Property defxmlns() As String
        Get
            Return privatedefxmlns
        End Get
        Set(ByVal value As String)
            privatedefxmlns = value
        End Set
    End Property

End Class


