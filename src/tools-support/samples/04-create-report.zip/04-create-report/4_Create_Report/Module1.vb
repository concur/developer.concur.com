﻿Module Module1

    Sub Main()
        Dim user As String = "LoginId"
        Dim password As String = "Password"
        Dim key As String = "Consumer Key"

        Dim AuthorizationTokenURL As String = "https://implementation.concursolutions.com/net2/oauth2/accesstoken.ashx"

        Dim expMgr As New ManageExpense(key, user, password, AuthorizationTokenURL)

        Dim rptBatch As New List(Of ExpenseReportHeader)
        Dim rptHeader As New ExpenseReportHeader

        rptHeader.defxmlns = "http://www.concursolutions.com/api/expense/expensereport/2011/03"

        rptHeader.LoginId = ""
        rptHeader.Name = ""
        rptHeader.Purpose = ""
        rptHeader.UserDefinedDate = ""
        rptHeader.Index = "1"
        rptHeader.LangCode = "en_US"
        rptHeader.Role = "TRAVELER"
        rptHeader.Custom3 = ""

        Dim results As New ExpenseReportStatus

        Dim ReportURL As String = "https://implementation.concursolutions.com/api/expense/expensereport/v1.1/report/batch"

        results = expMgr.PostExpenseReportHearderBatch(rptHeader, ReportURL)

        ''Display Purposes
        Console.WriteLine("Response Status: " + results.Status.ToString)
        Console.WriteLine("****************************")
        Console.WriteLine("Report Details: " + results.ReportDetailsUrl.ToString)

        Dim rptDetail As New ReportDetails

        rptDetail = expMgr.GetReportDetails(results.ReportDetailsUrl.ToString)
        Console.WriteLine("")
        Console.WriteLine("Report Name: " + rptDetail.ReportName.ToString)
        Console.WriteLine("Report ID: " + rptDetail.ReportId.ToString)

        Console.ReadLine()

    End Sub

End Module
