﻿Imports System.IO
Imports System.Net
Imports System.Text
Imports Newtonsoft.Json

Module Module1

    Sub Main()

        'USED FOR WRITTING JWT TPKEN DATA TO A FILE
        Dim FILE_NAME As String = "C:\JWT_Auth_Log.txt"
        Dim objWriter As New System.IO.StreamWriter(FILE_NAME, False)

        Try
            '***FOR CLIENT CREDENTIALS GRANT***
            Dim METHOD As String = "POST"
            Dim CONTENT As String = "application/json; charset=utf-8"
            Dim SERVER As String = "https://us.api.concursolutions.com/oauth2/v0/token"
            Dim CLIENT_ID As String = "client_id=YOUR ID HERE"
            Dim CLIENT_SRT As String = "client_secret=YOUR ID HERE"
            Dim SCOPE As String = "scope=EXPRPT+IMAGE+LIST+EXTRCT+USER"
            Dim GRANT As String = "grant_type=client_credentials"
            Console.WriteLine(SERVER + "?" + CLIENT_ID + "&" + CLIENT_SRT + "&" + SCOPE + "&" + GRANT, "", METHOD, CONTENT)

            Dim RESUTLS As String = execute(SERVER + "?" + CLIENT_ID + "&" + CLIENT_SRT + "&" + SCOPE + "&" + GRANT, "", METHOD, CONTENT)

            '***FOR PASSWORD GRANT***
            'Dim METHOD As String = "POST"
            'Dim CONTENT As String = "application/json; charset=utf-8"
            'Dim SERVER As String = "https://us.api.concursolutions.com/oauth2/v0/token"
            'Dim CLIENT_ID As String = "client_id=YOUR ID HERE"
            'Dim CLIENT_SRT As String = "client_secret=YOUR ID HERE"
            'Dim GRANT As String = "grant_type=password"
            'Dim USER As String = "username=YOUR USER"
            'Dim PASS As String = "password=YOUR PASSWORD"
            'Console.WriteLine(SERVER + "?" + CLIENT_ID + "&" + CLIENT_SRT + "&" + GRANT + "&" + USER + "&" + PASS, "", METHOD, CONTENT)

            'Dim RESUTLS As String = execute(SERVER + "?" + CLIENT_ID + "&" + CLIENT_SRT + "&" + GRANT + "&" + USER + "&" + PASS, "", METHOD, CONTENT)


            Console.Write(RESUTLS)
            objWriter.WriteLine(RESUTLS)
            objWriter.Close()
            Console.ReadKey()

        Catch ex1 As Exception
            Try
                objWriter.Close()
            Catch ex2 As Exception
                'ignore
            End Try
        End Try
    End Sub

    Private Function execute(ByVal url As String, ByVal postData As String, ByVal method As String, ByVal contentType As String)
        Dim toReturn As String = ""
        Try
            Dim response As HttpWebResponse = RequestWrapper.MakeHttpTokenRequest_ContentSupport(url, method, postData, contentType)
            toReturn = getResponseContentResults(response)
            Return toReturn
        Catch ex As Exception
            Dim message As String = ex.Message
            toReturn = message
            Return toReturn
        End Try
        Return toReturn
    End Function

    Private Function getResponseContentResults(ByVal responseWeb As HttpWebResponse) As String
        Dim sb As New System.Text.StringBuilder()
        Dim statCode As Integer = System.Convert.ToInt32(responseWeb.StatusCode)
        sb.Append("HTTP Status:" + responseWeb.StatusCode.ToString() + Environment.NewLine())
        sb.Append("HTTP Status Code:" + statCode.ToString() + Environment.NewLine())
        sb.Append("HTTP Method:" + responseWeb.Method.ToString() + Environment.NewLine())
        sb.Append("Content Type:" + responseWeb.ContentType.ToString() + Environment.NewLine())
        sb.Append("Content Length:" + responseWeb.ContentLength.ToString() + Environment.NewLine())

        If (responseWeb.ContentLength > 0) And (responseWeb.ContentType.Contains("application/json")) Then
            Dim json As String = getJsonFromStreamtoString(responseWeb.GetResponseStream())
            sb.Append(Environment.NewLine() + json + Environment.NewLine())
        ElseIf responseWeb.ContentLength > 0 Then
            Dim content As String = getStringFromStream(responseWeb.GetResponseStream())
            sb.Append(Environment.NewLine() + content + Environment.NewLine())
        End If
        Return sb.ToString()
    End Function

    Private Function getJsonFromStreamtoString(ByVal stream As Stream) As String
        Dim toReturn As String = ""
        Using reader = New StreamReader(stream, Encoding.UTF8)
            toReturn = reader.ReadToEnd()
            toReturn = JsonConvert.SerializeObject(JsonConvert.DeserializeObject(toReturn), Newtonsoft.Json.Formatting.Indented)
            Return toReturn
        End Using
    End Function

    Private Function getStringFromStream(ByVal stream As Stream) As String
        Dim toReturn As String = ""
        Using reader = New StreamReader(stream, Encoding.UTF8)
            toReturn = reader.ReadToEnd()
            Return toReturn
        End Using
    End Function
End Module
