﻿Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Linq
Imports System.Net
Imports System.Text
Imports System.Xml

Public Class Definition

    Private privateId As String
    Public Property Id() As String
        Get
            Return privateId
        End Get
        Set(ByVal value As String)
            privateId = value
        End Set
    End Property

    Private privateName As String
    Public Property Name() As String
        Get
            Return privateName
        End Get
        Set(ByVal value As String)
            privateName = value
        End Set
    End Property

    Private privateJobLink As String
    Public Property JobLink() As String
        Get
            Return privateJobLink
        End Get
        Set(ByVal value As String)
            privateJobLink = value
        End Set
    End Property

    Private privatedefxmlns As String
    Public Property defxmlns() As String
        Get
            Return privatedefxmlns
        End Get
        Set(ByVal value As String)
            privatedefxmlns = value
        End Set
    End Property

    Public Shared Function getDefinitions(ByVal uri As String, ByVal token As String) As DefinitionList

        ' Send the request
        Dim response As HttpWebResponse = ManageExtracts.HttpWrapper.MakeHttpTokenRequest(uri, "GET", "", token)

        Dim xml As String = Utilities.getStringFromStream(response.GetResponseStream())

        ' Parse the xml into a list of definitions
        Dim definitions As New DefinitionList()
        If (xml = "") Then
            Return Nothing
        End If
        Dim xmlReader As XmlReader = xmlReader.Create(New StringReader(xml))
        definitions.parseDefinitions(xmlReader)

        Return definitions

    End Function

End Class

Public Class DefinitionList
    Inherits List(Of Definition)

    Private privatedefxmlns As String
    Public Property defxmlns() As String
        Get
            Return privatedefxmlns
        End Get
        Set(ByVal value As String)
            privatedefxmlns = value
        End Set
    End Property

    Public Sub parseDefinitions(ByVal xmlreader As XmlReader)
        Dim currentDef As Definition = Nothing
        Do While xmlreader.Read()

            If defxmlns = "" Then
                defxmlns = xmlreader.GetAttribute(0).ToString
            End If

            Select Case xmlreader.NodeType

                Case XmlNodeType.Element ' The node is an element.
                    If xmlreader.Name.Equals("definition") AndAlso xmlreader.IsStartElement() Then
                        currentDef = New Definition()
                        currentDef.defxmlns = defxmlns
                    ElseIf xmlreader.Name.Equals("id") Then
                        xmlreader.Read()
                        currentDef.Id = xmlreader.Value

                    ElseIf xmlreader.Name.Equals("job-link") Then
                        xmlreader.Read()
                        currentDef.JobLink = xmlreader.Value

                    ElseIf xmlreader.Name.Equals("name") Then
                        xmlreader.Read()
                        currentDef.Name = xmlreader.Value
                    End If

                Case XmlNodeType.EndElement 'Reached the end of the element.
                    If xmlreader.Name.Equals("definition") Then
                        If currentDef IsNot Nothing Then
                            Add(currentDef)
                            currentDef = Nothing
                        End If
                    End If

                Case Else
            End Select
        Loop
    End Sub

End Class
