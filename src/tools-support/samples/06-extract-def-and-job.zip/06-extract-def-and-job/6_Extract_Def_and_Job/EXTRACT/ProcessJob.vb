﻿Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Linq
Imports System.Net
Imports System.Text
Imports System.Xml

Public Class ProcessJob

    Private privateId As String
    Public Property Id() As String
        Get
            Return privateId
        End Get
        Set(ByVal value As String)
            privateId = value
        End Set
    End Property
    Private privateStatusLink As String
    Public Property StatusLink() As String
        Get
            Return privateStatusLink
        End Get
        Set(ByVal value As String)
            privateStatusLink = value
        End Set
    End Property
    Private privateStartTime As String
    Public Property StartTime() As String
        Get
            Return privateStartTime
        End Get
        Set(ByVal value As String)
            privateStartTime = value
        End Set
    End Property
    Private privateStopTime As String
    Public Property StopTime() As String
        Get
            Return privateStopTime
        End Get
        Set(ByVal value As String)
            privateStopTime = value
        End Set
    End Property
    Private privateStatus As String
    Public Property Status() As String
        Get
            Return privateStatus
        End Get
        Set(ByVal value As String)
            privateStatus = value
        End Set
    End Property
    Private privateFileLink As String
    Public Property FileLink() As String
        Get
            Return privateFileLink
        End Get
        Set(ByVal value As String)
            privateFileLink = value
        End Set
    End Property

    Public Shared Function getJobs(ByVal uri As String, ByVal token As String) As JobList

        ' Send the request
        Dim response As HttpWebResponse = ManageExtracts.HttpWrapper.MakeHttpTokenRequest(uri, "GET", "", token)

        ' Return the list of jobs contained within the response
        Return getJobsFromResponse(response)

    End Function

    Private Shared Function getJobsFromResponse(ByVal response As HttpWebResponse) As JobList

        ' Generate a string from the response
        Dim xml As String = Utilities.getStringFromStream(response.GetResponseStream())

        ' Parse the xml into a list
        Dim jobs As New JobList()
        Dim xmlReader As XmlReader = xmlReader.Create(New StringReader(xml))
        jobs.parseJobs(xmlReader)

        Return jobs

    End Function

End Class

Public Class JobList
    Inherits List(Of ProcessJob)

    Public Sub parseJobs(ByVal xmlreader As XmlReader)

        Dim currentJob As ProcessJob = Nothing

        Do While xmlreader.Read()
            Select Case xmlreader.NodeType
                Case XmlNodeType.Element ' The node is an element.
                    If xmlreader.Name.Equals("job") AndAlso xmlreader.IsStartElement() Then
                        currentJob = New ProcessJob()
                    ElseIf xmlreader.Name.Equals("id") Then
                        xmlreader.Read()
                        currentJob.Id = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("status-link") Then
                        xmlreader.Read()
                        currentJob.StatusLink = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("start-time") Then
                        xmlreader.Read()
                        currentJob.StartTime = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("stop-time") Then
                        xmlreader.Read()
                        currentJob.StopTime = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("status") Then
                        xmlreader.Read()
                        currentJob.Status = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("file-link") Then
                        xmlreader.Read()
                        currentJob.FileLink = xmlreader.Value
                    End If

                Case XmlNodeType.EndElement 'Reached the end of the element.
                    If xmlreader.Name.Equals("job") Then
                        If currentJob IsNot Nothing Then
                            Add(currentJob)
                            currentJob = Nothing
                        End If
                    End If
                Case Else
            End Select
        Loop

    End Sub

End Class

