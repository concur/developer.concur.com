﻿Module Module1

    Sub Main()
        Dim user As String = "LoginId"
        Dim password As String = "Password"
        Dim key As String = "Consumer Key"

        Dim AuthorizationTokenURL As String = "https://www.concursolutions.com/net2/oauth2/accesstoken.ashx"

        Dim extMgr As New ManageExtracts(key, user, password, AuthorizationTokenURL)

        Dim ExtractURL As String = "https://www.concursolutions.com/api/expense/extract/v1.0/"

        Dim defLst As New DefinitionList
        defLst = extMgr.GetExtractDefinitionList(ExtractURL)

        ''Display Purposes
        Console.WriteLine("Extract Definitions")
        Console.WriteLine("************************************")
        For Each def As Definition In defLst
            Console.WriteLine("Name: " + def.Name.ToString)
            Console.WriteLine("ID: " + def.Id.ToString)
            Console.WriteLine("Job URI: " + def.JobLink.ToString)
            Console.WriteLine("************************************")
        Next
        Console.WriteLine()
        Console.ReadLine()

        Dim jbLst As New JobList
        jbLst = extMgr.GetExtractJobList(defLst.Item(2))

        Console.WriteLine("Definition Jobs")
        Console.WriteLine("************************************")
        For Each jb As ProcessJob In jbLst
            If jb.Id <> "" Then
                Console.WriteLine("ID: " + jb.Id.ToString)
                Console.WriteLine("Job Status: " + jb.Status.ToString)
                If jb.FileLink IsNot Nothing Then
                    Console.WriteLine("File Link: " + jb.FileLink.ToString)
                End If
                Console.WriteLine("************************************")
            End If
        Next
        Console.WriteLine()
        Console.ReadLine()
    End Sub

End Module
