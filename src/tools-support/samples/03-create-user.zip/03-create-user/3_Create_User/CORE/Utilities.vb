﻿Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Linq
Imports System.Text
Imports System.Xml

Public Class Utilities

    Public Shared Function getStringFromStreamtoString(ByVal stream As Stream) As String

        '' Adjust settings so XML will be formatted (indented) properly
        Dim writerSettings As New XmlWriterSettings()
        writerSettings.Indent = True
        writerSettings.ConformanceLevel = ConformanceLevel.Auto

        '' Write the XML response to a string builder
        Dim strBuilder As New StringBuilder(10000)
        Dim writer As XmlWriter = XmlWriter.Create(strBuilder, writerSettings)
        Dim doc As New XDocument(New XDeclaration("1.0", "UTF-8", "yes"))
        doc = XDocument.Load(stream)
        doc.WriteTo(writer)

        Return doc.ToString()

    End Function

    Public Shared Function getStringFromStream(ByVal stream As Stream) As String

        '' Adjust settings so XML will be formatted (indented) properly
        Dim writerSettings As New XmlWriterSettings()
        writerSettings.Indent = True
        writerSettings.ConformanceLevel = ConformanceLevel.Fragment

        '' Write the XML response to a string builder
        Dim strBuilder As New StringBuilder(10000)
        Dim writer As XmlWriter = XmlWriter.Create(strBuilder, writerSettings)
        Dim doc As New XmlDocument()
        doc.Load(stream)
        doc.WriteTo(writer)

        Return doc.InnerXml.ToString()

    End Function

    Public Shared Function getxmlFromStream(ByVal stream As Stream) As XmlDocument

        '' Adjust settings so XML will be formatted (indented) properly
        Dim writerSettings As New XmlWriterSettings()
        writerSettings.Indent = True
        writerSettings.ConformanceLevel = ConformanceLevel.Fragment

        '' Write the XML response to a string builder
        Dim strBuilder As New StringBuilder(10000)
        Dim writer As XmlWriter = XmlWriter.Create(strBuilder, writerSettings)
        Dim doc As New XmlDocument()
        doc.Load(stream)
        doc.WriteTo(writer)

        Return doc

    End Function

End Class
