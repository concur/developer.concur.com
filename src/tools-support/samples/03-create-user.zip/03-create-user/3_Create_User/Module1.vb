﻿Module Module1

    Sub Main()
        Dim user As String = "LoginId"
        Dim password As String = "Password"
        Dim key As String = "Consumer Key"

        Dim AuthorizationTokenURL As String = "https://www.concursolutions.com/net2/oauth2/accesstoken.ashx"

        Dim userMgr As New ManageUsers(key, user, password, AuthorizationTokenURL)

        Dim FormFieldsURL As String = "https://www.concursolutions.com/api/user/v1.0/FormFields"

        Dim frmFields As New FormFieldsList
        frmFields = userMgr.getformfields(FormFieldsURL)

        Dim userelements As New UsersCls
        Dim userlist As New UsersLists

        userlist.defxmlns = "http://www.concursolutions.com/api/user/2011/02"
        userelements.EmpID = ""
        userelements.FeedRecordNumber = "1"
        userelements.LoginID = ""
        userelements.LocaleName = "en_US"
        userelements.Active = "Y"
        userelements.Password = ""
        userelements.FirstName = ""
        userelements.LastName = ""
        userelements.Mi = ""
        userelements.EmailAddress = ""
        userelements.LedgerKey = "Default"
        userelements.CtryCode = "US"
        userelements.Custom21 = "Default"
        userelements.CtrySubCode = "US-LA"
        userelements.CrnKey = "USD"
        userelements.ExpenseApprover = "N"
        userelements.ExpenseUser = "Y"
        userelements.TripUser = "N"
        userelements.IsTestEmp = "N"

        userlist.Add(userelements)

        Dim UsersURL As String = "https://www.concursolutions.com/api/user/v1.0/Users"

        Dim userResp As New UsersResponse
        userResp = userMgr.CreateUser(userlist, UsersURL)

        ''Display Purposes
        Console.WriteLine("Response # Records Posted Successfully: " + userResp.recordssucceeded.ToString)
        Console.WriteLine("****************************")

        Dim GetUserURL As String = "https://www.concursolutions.com/api/user/v1.0/User/"

        Dim userPro As New UserProfile
        userPro = userMgr.GetUser(userelements.LoginID.ToString, GetUserURL)

        Console.WriteLine("NAME: " + userPro.FirstName.ToString + " " + userPro.LastName.ToString)
        Console.WriteLine("EMPLOYEE ID: " + userPro.EmpID.ToString)
        Console.WriteLine("Login ID: " + userPro.LoginID.ToString)

        Console.ReadLine()
    End Sub

End Module
