﻿Imports System.Xml
Imports System.Net
Imports System.IO


Public Class UsersCls

    Private uriReturn_Renamed As String = ""
    Public Overridable Property uriReturn As String
        Get
            Return uriReturn_Renamed
        End Get
        Set(ByVal value As String)
            uriReturn_Renamed = value
        End Set
    End Property
    Private baseurl_Renamed As String = ""
    Public Overridable Property baseurl As String
        Get
            Return baseurl_Renamed
        End Get
        Set(ByVal value As String)
            baseurl_Renamed = value
        End Set
    End Property
    Private EmpID_Renamed As String = ""
    Public Overridable Property EmpID As String
        Get
            Return EmpID_Renamed
        End Get
        Set(ByVal value As String)
            EmpID_Renamed = value
        End Set
    End Property
    Private FeedRecordNumber_Renamed As String = ""
    Public Overridable Property FeedRecordNumber As String
        Get
            Return FeedRecordNumber_Renamed
        End Get
        Set(ByVal value As String)
            FeedRecordNumber_Renamed = value
        End Set
    End Property
    Private LoginID_Renamed As String = ""
    Public Overridable Property LoginID As String
        Get
            Return LoginID_Renamed
        End Get
        Set(ByVal value As String)
            LoginID_Renamed = value
        End Set
    End Property
    Private LocaleName_Renamed As String = ""
    Public Overridable Property LocaleName As String
        Get
            Return LocaleName_Renamed
        End Get
        Set(ByVal value As String)
            LocaleName_Renamed = value
        End Set
    End Property
    Private Active_Renamed As String = ""
    Public Overridable Property Active As String
        Get
            Return Active_Renamed
        End Get
        Set(ByVal value As String)
            Active_Renamed = value
        End Set
    End Property
    Private Password_Renamed As String = ""
    Public Overridable Property Password As String
        Get
            Return Password_Renamed
        End Get
        Set(ByVal value As String)
            Password_Renamed = value
        End Set
    End Property
    Private FirstName_Renamed As String = ""
    Public Overridable Property FirstName As String
        Get
            Return FirstName_Renamed
        End Get
        Set(ByVal value As String)
            FirstName_Renamed = value
        End Set
    End Property
    Private LastName_Renamed As String = ""
    Public Overridable Property LastName As String
        Get
            Return LastName_Renamed
        End Get
        Set(ByVal value As String)
            LastName_Renamed = value
        End Set
    End Property
    Private Mi_Renamed As String = ""
    Public Overridable Property Mi As String
        Get
            Return Mi_Renamed
        End Get
        Set(ByVal value As String)
            Mi_Renamed = value
        End Set
    End Property
    Private EmailAddress_Renamed As String = ""
    Public Overridable Property EmailAddress As String
        Get
            Return EmailAddress_Renamed
        End Get
        Set(ByVal value As String)
            EmailAddress_Renamed = value
        End Set
    End Property
    Private LedgerKey_Renamed As String = ""
    Public Overridable Property LedgerKey As String
        Get
            Return LedgerKey_Renamed
        End Get
        Set(ByVal value As String)
            LedgerKey_Renamed = value
        End Set
    End Property
    Private OrgUnit1_Renamed As String = ""
    Public Overridable Property OrgUnit1 As String
        Get
            Return OrgUnit1_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit1_Renamed = value
        End Set
    End Property
    Private OrgUnit2_Renamed As String = ""
    Public Overridable Property OrgUnit2 As String
        Get
            Return OrgUnit2_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit2_Renamed = value
        End Set
    End Property
    Private OrgUnit3_Renamed As String = ""
    Public Overridable Property OrgUnit3 As String
        Get
            Return OrgUnit3_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit3_Renamed = value
        End Set
    End Property
    Private OrgUnit4_Renamed As String = ""
    Public Overridable Property OrgUnit4 As String
        Get
            Return OrgUnit4_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit4_Renamed = value
        End Set
    End Property
    Private OrgUnit5_Renamed As String = ""
    Public Overridable Property OrgUnit5 As String
        Get
            Return OrgUnit5_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit5_Renamed = value
        End Set
    End Property
    Private OrgUnit6_Renamed As String = ""
    Public Overridable Property OrgUnit6 As String
        Get
            Return OrgUnit6_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit6_Renamed = value
        End Set
    End Property
    Private Custom1_Renamed As String = ""
    Public Overridable Property Custom1 As String
        Get
            Return Custom1_Renamed
        End Get
        Set(ByVal value As String)
            Custom1_Renamed = value
        End Set
    End Property
    Private Custom2_Renamed As String = ""
    Public Overridable Property Custom2 As String
        Get
            Return Custom2_Renamed
        End Get
        Set(ByVal value As String)
            Custom2_Renamed = value
        End Set
    End Property
    Private Custom3_Renamed As String = ""
    Public Overridable Property Custom3 As String
        Get
            Return Custom3_Renamed
        End Get
        Set(ByVal value As String)
            Custom3_Renamed = value
        End Set
    End Property
    Private Custom4_Renamed As String = ""
    Public Overridable Property Custom4 As String
        Get
            Return Custom4_Renamed
        End Get
        Set(ByVal value As String)
            Custom4_Renamed = value
        End Set
    End Property
    Private Custom5_Renamed As String = ""
    Public Overridable Property Custom5 As String
        Get
            Return Custom5_Renamed
        End Get
        Set(ByVal value As String)
            Custom5_Renamed = value
        End Set
    End Property
    Private Custom6_Renamed As String = ""
    Public Overridable Property Custom6 As String
        Get
            Return Custom6_Renamed
        End Get
        Set(ByVal value As String)
            Custom6_Renamed = value
        End Set
    End Property
    Private Custom7_Renamed As String = ""
    Public Overridable Property Custom7 As String
        Get
            Return Custom7_Renamed
        End Get
        Set(ByVal value As String)
            Custom7_Renamed = value
        End Set
    End Property
    Private Custom8_Renamed As String = ""
    Public Overridable Property Custom8 As String
        Get
            Return Custom8_Renamed
        End Get
        Set(ByVal value As String)
            Custom8_Renamed = value
        End Set
    End Property
    Private Custom9_Renamed As String = ""
    Public Overridable Property Custom9 As String
        Get
            Return Custom9_Renamed
        End Get
        Set(ByVal value As String)
            Custom9_Renamed = value
        End Set
    End Property
    Private Custom10_Renamed As String = ""
    Public Overridable Property Custom10 As String
        Get
            Return Custom10_Renamed
        End Get
        Set(ByVal value As String)
            Custom10_Renamed = value
        End Set
    End Property
    Private Custom11_Renamed As String = ""
    Public Overridable Property Custom11 As String
        Get
            Return Custom11_Renamed
        End Get
        Set(ByVal value As String)
            Custom11_Renamed = value
        End Set
    End Property
    Private Custom12_Renamed As String = ""
    Public Overridable Property Custom12 As String
        Get
            Return Custom12_Renamed
        End Get
        Set(ByVal value As String)
            Custom12_Renamed = value
        End Set
    End Property
    Private Custom13_Renamed As String = ""
    Public Overridable Property Custom13 As String
        Get
            Return Custom13_Renamed
        End Get
        Set(ByVal value As String)
            Custom13_Renamed = value
        End Set
    End Property
    Private Custom14_Renamed As String = ""
    Public Overridable Property Custom14 As String
        Get
            Return Custom14_Renamed
        End Get
        Set(ByVal value As String)
            Custom14_Renamed = value
        End Set
    End Property
    Private Custom15_Renamed As String = ""
    Public Overridable Property Custom15 As String
        Get
            Return Custom15_Renamed
        End Get
        Set(ByVal value As String)
            Custom15_Renamed = value
        End Set
    End Property
    Private Custom16_Renamed As String = ""
    Public Overridable Property Custom16 As String
        Get
            Return Custom16_Renamed
        End Get
        Set(ByVal value As String)
            Custom16_Renamed = value
        End Set
    End Property
    Private Custom17_Renamed As String = ""
    Public Overridable Property Custom17 As String
        Get
            Return Custom17_Renamed
        End Get
        Set(ByVal value As String)
            Custom17_Renamed = value
        End Set
    End Property
    Private Custom18_Renamed As String = ""
    Public Overridable Property Custom18 As String
        Get
            Return Custom18_Renamed
        End Get
        Set(ByVal value As String)
            Custom18_Renamed = value
        End Set
    End Property
    Private Custom19_Renamed As String = ""
    Public Overridable Property Custom19 As String
        Get
            Return Custom19_Renamed
        End Get
        Set(ByVal value As String)
            Custom19_Renamed = value
        End Set
    End Property
    Private Custom20_Renamed As String = ""
    Public Overridable Property Custom20 As String
        Get
            Return Custom20_Renamed
        End Get
        Set(ByVal value As String)
            Custom20_Renamed = value
        End Set
    End Property
    Private Custom21_Renamed As String = ""
    Public Overridable Property Custom21 As String
        Get
            Return Custom21_Renamed
        End Get
        Set(ByVal value As String)
            Custom21_Renamed = value
        End Set
    End Property
    Private CtryCode_Renamed As String = ""
    Public Overridable Property CtryCode As String
        Get
            Return CtryCode_Renamed
        End Get
        Set(ByVal value As String)
            CtryCode_Renamed = value
        End Set
    End Property
    Private CashAdvanceAccountCode_Renamed As String = ""
    Public Overridable Property CashAdvanceAccountCode As String
        Get
            Return CashAdvanceAccountCode_Renamed
        End Get
        Set(ByVal value As String)
            CashAdvanceAccountCode_Renamed = value
        End Set
    End Property
    Private CrnKey_Renamed As String = ""
    Public Overridable Property CrnKey As String
        Get
            Return CrnKey_Renamed
        End Get
        Set(ByVal value As String)
            CrnKey_Renamed = value
        End Set
    End Property
    Private CtrySubCode_Renamed As String = ""
    Public Overridable Property CtrySubCode As String
        Get
            Return CtrySubCode_Renamed
        End Get
        Set(ByVal value As String)
            CtrySubCode_Renamed = value
        End Set
    End Property
    Private ExpenseUser_Renamed As String = ""
    Public Overridable Property ExpenseUser As String
        Get
            Return ExpenseUser_Renamed
        End Get
        Set(ByVal value As String)
            ExpenseUser_Renamed = value
        End Set
    End Property
    Private ExpenseApprover_Renamed As String = ""
    Public Overridable Property ExpenseApprover As String
        Get
            Return ExpenseApprover_Renamed
        End Get
        Set(ByVal value As String)
            ExpenseApprover_Renamed = value
        End Set
    End Property
    Private TripUser_Renamed As String = ""
    Public Overridable Property TripUser As String
        Get
            Return TripUser_Renamed
        End Get
        Set(ByVal value As String)
            TripUser_Renamed = value
        End Set
    End Property
    Private InvoiceUser_Renamed As String = ""
    Public Overridable Property InvoiceUser As String
        Get
            Return InvoiceUser_Renamed
        End Get
        Set(ByVal value As String)
            InvoiceUser_Renamed = value
        End Set
    End Property
    Private InvoiceApprover_Renamed As String = ""
    Public Overridable Property InvoiceApprover As String
        Get
            Return InvoiceApprover_Renamed
        End Get
        Set(ByVal value As String)
            InvoiceApprover_Renamed = value
        End Set
    End Property
    Private ExpenseApproverEmployeeID_Renamed As String = ""
    Public Overridable Property ExpenseApproverEmployeeID As String
        Get
            Return ExpenseApproverEmployeeID_Renamed
        End Get
        Set(ByVal value As String)
            ExpenseApproverEmployeeID_Renamed = value
        End Set
    End Property
    Private IsTestEmp_Renamed As String = ""
    Public Overridable Property IsTestEmp As String
        Get
            Return IsTestEmp_Renamed
        End Get
        Set(ByVal value As String)
            IsTestEmp_Renamed = value
        End Set
    End Property
    Private privatedefxmlns As String
    Public Property defxmlns() As String
        Get
            Return privatedefxmlns
        End Get
        Set(ByVal value As String)
            privatedefxmlns = value
        End Set
    End Property
    Private BiHierNodeKey_Renamed As String = ""
    Public Overridable Property BiHierNodeKey As String
        Get
            Return BiHierNodeKey_Renamed
        End Get
        Set(ByVal value As String)
            BiHierNodeKey_Renamed = value
        End Set
    End Property
    Private NewLoginID_Renamed As String = ""
    Public Overridable Property NewLoginID As String
        Get
            Return NewLoginID_Renamed
        End Get
        Set(ByVal value As String)
            NewLoginID_Renamed = value
        End Set
    End Property

    Public Shared Function getUser(ByVal uri As String, ByVal token As String) As UsersResponse

        Dim responses As HttpWebResponse = ManageUsers.HttpWrapper.MakeHttpTokenRequest(uri, "GET", "", token)

        Return getResponseList(responses)

    End Function

    Public Shared Function addUser(ByVal newusers As UsersLists, ByVal uri As String, ByVal token As String) As UsersResponse

        Dim newUserXml As String = create(newusers)

        Dim responses As HttpWebResponse = ManageUsers.HttpWrapper.MakeHttpTokenRequest(uri, "POST", newUserXml, token)

        Return getResponseList(responses)

    End Function

    Private Shared Function getResponseList(ByVal response As HttpWebResponse) As UsersResponse

        ' Generate a string from the response
        Dim xml As String = Utilities.getStringFromStream(response.GetResponseStream())

        ' Parse the xml into a list of reorts      
        If (xml = "") Then
            Return Nothing
        End If
        Dim xmlReader As XmlReader = xmlReader.Create(New StringReader(xml))
        Dim RespOut As UsersResponse = UsersResponse.parseReportsandErrors(xmlReader)

        Return RespOut

    End Function

    Public Shared Function create(ByVal usergroup As UsersLists) As String

        'create xml
        Dim response As New XmlDocument

        Dim root As XmlElement = response.CreateElement("batch")
        'set attributes
        root.SetAttribute("xmlns", usergroup.defxmlns.ToString)
        response.AppendChild(root)

        If usergroup.Count <> 0 Then
            For Each userdata As UsersCls In usergroup
                Dim newuser As XmlElement = UsersSerialize(response, userdata)
                root.AppendChild(newuser)
            Next userdata
        End If

        Return response.InnerXml.ToString
    End Function

    Private Shared Function UsersSerialize(ByVal xml As XmlDocument, ByVal userdata As UsersCls) As XmlElement
        Dim users As XmlElement = xml.CreateElement("UserProfile")
        append(xml, users, "EmpId", userdata.EmpID)
        append(xml, users, "FeedRecordNumber", userdata.FeedRecordNumber)
        append(xml, users, "LoginId", userdata.LoginID)
        append(xml, users, "LocaleName", userdata.LocaleName)
        append(xml, users, "Active", userdata.Active)
        append(xml, users, "Password", userdata.Password)
        append(xml, users, "FirstName", userdata.FirstName)
        append(xml, users, "LastName", userdata.LastName)
        append(xml, users, "Mi", userdata.Mi)
        append(xml, users, "EmailAddress", userdata.EmailAddress)
        append(xml, users, "LedgerKey", userdata.LedgerKey)
        append(xml, users, "OrgUnit1", userdata.OrgUnit1)
        append(xml, users, "OrgUnit2", userdata.OrgUnit2)
        append(xml, users, "OrgUnit3", userdata.OrgUnit3)
        append(xml, users, "OrgUnit4", userdata.OrgUnit4)
        append(xml, users, "OrgUnit5", userdata.OrgUnit5)
        append(xml, users, "OrgUnit6", userdata.OrgUnit6)
        append(xml, users, "Custom1", userdata.Custom1)
        append(xml, users, "Custom2", userdata.Custom2)
        append(xml, users, "Custom3", userdata.Custom3)
        append(xml, users, "Custom4", userdata.Custom4)
        append(xml, users, "Custom5", userdata.Custom5)
        append(xml, users, "Custom6", userdata.Custom6)
        append(xml, users, "Custom7", userdata.Custom7)
        append(xml, users, "Custom8", userdata.Custom8)
        append(xml, users, "Custom9", userdata.Custom9)
        append(xml, users, "Custom10", userdata.Custom10)
        append(xml, users, "Custom11", userdata.Custom11)
        append(xml, users, "Custom12", userdata.Custom12)
        append(xml, users, "Custom13", userdata.Custom13)
        append(xml, users, "Custom14", userdata.Custom14)
        append(xml, users, "Custom15", userdata.Custom15)
        append(xml, users, "Custom16", userdata.Custom16)
        append(xml, users, "Custom17", userdata.Custom17)
        append(xml, users, "Custom18", userdata.Custom18)
        append(xml, users, "Custom19", userdata.Custom19)
        append(xml, users, "Custom20", userdata.Custom20)
        append(xml, users, "Custom21", userdata.Custom21)
        append(xml, users, "CtryCode", userdata.CtryCode)
        append(xml, users, "CashAdvanceAccountCode", userdata.CashAdvanceAccountCode)
        append(xml, users, "CrnKey", userdata.CrnKey)
        append(xml, users, "CtrySubCode", userdata.CtrySubCode)
        append(xml, users, "ExpenseUser", userdata.ExpenseUser)
        append(xml, users, "ExpenseApprover", userdata.ExpenseApprover)
        append(xml, users, "TripUser", userdata.TripUser)
        append(xml, users, "InvoiceUser", userdata.InvoiceUser)
        append(xml, users, "InvoiceApprover", userdata.InvoiceApprover)
        append(xml, users, "ExpenseApproverEmployeeID", userdata.ExpenseApproverEmployeeID)
        append(xml, users, "IsTestEmp", userdata.IsTestEmp)
        append(xml, users, "BiHierNodeKey", userdata.BiHierNodeKey)
        append(xml, users, "NewLoginID", userdata.NewLoginID)

        Return users
    End Function

    Private Shared Sub append(ByVal xml As XmlDocument, ByVal parent As XmlElement, ByVal tagName As String, ByVal value As String)
        Dim node As XmlElement

        If (value IsNot Nothing AndAlso value IsNot "") Then

            node = xml.CreateElement(tagName)
            node.InnerText = value.ToString()
            parent.AppendChild(node)
 
        End If

    End Sub
End Class

Public Class UsersLists
    Inherits List(Of UsersCls)
    Private privatedefxmlns As String
    Public Property defxmlns() As String
        Get
            Return privatedefxmlns
        End Get
        Set(ByVal value As String)
            privatedefxmlns = value
        End Set
    End Property
End Class

Public Class UsersStatus

    Private EmployeeID_Renamed As String = ""
    Public Overridable Property EmployeeID As String
        Get
            Return EmployeeID_Renamed
        End Get
        Set(ByVal value As String)
            EmployeeID_Renamed = value
        End Set
    End Property
    Private Status_Renamed As String = ""
    Public Overridable Property Status As String
        Get
            Return Status_Renamed
        End Get
        Set(ByVal value As String)
            Status_Renamed = value
        End Set
    End Property
    Private FeedRecordNumber_Renamed As String = ""
    Public Overridable Property FeedRecordNumber As String
        Get
            Return FeedRecordNumber_Renamed
        End Get
        Set(ByVal value As String)
            FeedRecordNumber_Renamed = value
        End Set
    End Property

End Class

Public Class UsersErrors

    Private FeedRecordNo_Renamed As String = ""
    Public Overridable Property FeedRecordNo As String
        Get
            Return FeedRecordNo_Renamed
        End Get
        Set(ByVal value As String)
            FeedRecordNo_Renamed = value
        End Set
    End Property
    Private EmployeeID_Renamed As String = ""
    Public Overridable Property EmployeeID As String
        Get
            Return EmployeeID_Renamed
        End Get
        Set(ByVal value As String)
            EmployeeID_Renamed = value
        End Set
    End Property
    Private message_Renamed As String = ""
    Public Overridable Property message As String
        Get
            Return message_Renamed
        End Get
        Set(ByVal value As String)
            message_Renamed = value
        End Set
    End Property

End Class

Public Class UsersResponse

    Private recordssucceeded_Renamed As String = ""
    Public Overridable Property recordssucceeded As String
        Get
            Return recordssucceeded_Renamed
        End Get
        Set(ByVal value As String)
            recordssucceeded_Renamed = value
        End Set
    End Property
    Private recordsfailed_Renamed As String = ""
    Public Overridable Property recordsfailed As String
        Get
            Return recordsfailed_Renamed
        End Get
        Set(ByVal value As String)
            recordsfailed_Renamed = value
        End Set
    End Property
    Private Statuses_Renamed As New List(Of UsersStatus)
    Public Overridable Property Statuses As List(Of UsersStatus)
        Get
            Return Statuses_Renamed
        End Get
        Set(ByVal value As List(Of UsersStatus))
            Statuses_Renamed = value
        End Set
    End Property
    Private Errors_Renamed As New List(Of UsersErrors)
    Public Overridable Property Errors As List(Of UsersErrors)
        Get
            Return Errors_Renamed
        End Get
        Set(ByVal value As List(Of UsersErrors))
            Errors_Renamed = value
        End Set
    End Property
    Private privatedefxmlns As String
    Public Property defxmlns() As String
        Get
            Return privatedefxmlns
        End Get
        Set(ByVal value As String)
            privatedefxmlns = value
        End Set
    End Property
    Public Shared Function parseReportsandErrors(ByVal xmlreader As XmlReader)

        Dim currentReport As UsersResponse = Nothing
        Dim errorReport As UsersErrors = Nothing
        Dim statusReport As UsersStatus = Nothing
        Do While xmlreader.Read()
            Select Case xmlreader.NodeType
                Case XmlNodeType.Element ' The node is an element.
                    If xmlreader.Name.Equals("user-batch-result") AndAlso xmlreader.IsStartElement() Then
                        currentReport = New UsersResponse
                        currentReport.defxmlns = xmlreader.NamespaceURI.ToString
                    ElseIf xmlreader.Name.Equals("records-succeeded") Then
                        xmlreader.Read()
                        currentReport.recordssucceeded = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("records-failed") Then
                        xmlreader.Read()
                        currentReport.recordsfailed = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("error") Then
                        errorReport = New UsersErrors
                    ElseIf xmlreader.Name.Equals("EmployeeID") And errorReport IsNot Nothing Then
                        xmlreader.Read()
                        errorReport.EmployeeID = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("message") Then
                        xmlreader.Read()
                        errorReport.message = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("FeedRecordNumber") And errorReport IsNot Nothing Then
                        xmlreader.Read()
                        errorReport.FeedRecordNo = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("UserInfo") Then
                        statusReport = New UsersStatus
                    ElseIf xmlreader.Name.Equals("EmployeeID") And statusReport IsNot Nothing Then
                        xmlreader.Read()
                        statusReport.EmployeeID = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Status") Then
                        xmlreader.Read()
                        statusReport.Status = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("FeedRecordNumber") And statusReport IsNot Nothing Then
                        xmlreader.Read()
                        statusReport.FeedRecordNumber = xmlreader.Value
                    End If
                Case XmlNodeType.EndElement 'Reached the end of the element.
                    If xmlreader.Name.Equals("user-batch-result") Then
                        If currentReport IsNot Nothing Then
                            'Add(currentReport)
                        End If
                    ElseIf xmlreader.Name.Equals("error") Then
                        If errorReport IsNot Nothing Then
                            currentReport.Errors.Add(errorReport)
                            errorReport = Nothing
                        End If
                    ElseIf xmlreader.Name.Equals("UserInfo") Then
                        If statusReport IsNot Nothing Then
                            currentReport.Statuses.Add(statusReport)
                            statusReport = Nothing
                        End If
                    End If
                Case Else
            End Select
        Loop
        Return currentReport
    End Function
End Class




