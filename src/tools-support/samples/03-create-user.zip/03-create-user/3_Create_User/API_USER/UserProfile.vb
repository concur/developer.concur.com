﻿Imports System.Xml
Imports System.Net
Imports System.IO

Public Class UserProfile

    Private uriReturn_Renamed As String = ""
    Public Overridable Property uriReturn As String
        Get
            Return uriReturn_Renamed
        End Get
        Set(ByVal value As String)
            uriReturn_Renamed = value
        End Set
    End Property
    Private baseurl_Renamed As String = ""
    Public Overridable Property baseurl As String
        Get
            Return baseurl_Renamed
        End Get
        Set(ByVal value As String)
            baseurl_Renamed = value
        End Set
    End Property
    Private EmpID_Renamed As String = ""
    Public Overridable Property EmpID As String
        Get
            Return EmpID_Renamed
        End Get
        Set(ByVal value As String)
            EmpID_Renamed = value
        End Set
    End Property
    Private FeedRecordNumber_Renamed As String = ""
    Public Overridable Property FeedRecordNumber As String
        Get
            Return FeedRecordNumber_Renamed
        End Get
        Set(ByVal value As String)
            FeedRecordNumber_Renamed = value
        End Set
    End Property
    Private LoginID_Renamed As String = ""
    Public Overridable Property LoginID As String
        Get
            Return LoginID_Renamed
        End Get
        Set(ByVal value As String)
            LoginID_Renamed = value
        End Set
    End Property
    Private LocaleName_Renamed As String = ""
    Public Overridable Property LocaleName As String
        Get
            Return LocaleName_Renamed
        End Get
        Set(ByVal value As String)
            LocaleName_Renamed = value
        End Set
    End Property
    Private Active_Renamed As String = ""
    Public Overridable Property Active As String
        Get
            Return Active_Renamed
        End Get
        Set(ByVal value As String)
            Active_Renamed = value
        End Set
    End Property
    Private Password_Renamed As String = ""
    Public Overridable Property Password As String
        Get
            Return Password_Renamed
        End Get
        Set(ByVal value As String)
            Password_Renamed = value
        End Set
    End Property
    Private FirstName_Renamed As String = ""
    Public Overridable Property FirstName As String
        Get
            Return FirstName_Renamed
        End Get
        Set(ByVal value As String)
            FirstName_Renamed = value
        End Set
    End Property
    Private LastName_Renamed As String = ""
    Public Overridable Property LastName As String
        Get
            Return LastName_Renamed
        End Get
        Set(ByVal value As String)
            LastName_Renamed = value
        End Set
    End Property
    Private Mi_Renamed As String = ""
    Public Overridable Property Mi As String
        Get
            Return Mi_Renamed
        End Get
        Set(ByVal value As String)
            Mi_Renamed = value
        End Set
    End Property
    Private EmailAddress_Renamed As String = ""
    Public Overridable Property EmailAddress As String
        Get
            Return EmailAddress_Renamed
        End Get
        Set(ByVal value As String)
            EmailAddress_Renamed = value
        End Set
    End Property
    Private LedgerKey_Renamed As String = ""
    Public Overridable Property LedgerKey As String
        Get
            Return LedgerKey_Renamed
        End Get
        Set(ByVal value As String)
            LedgerKey_Renamed = value
        End Set
    End Property
    Private OrgUnit1_Renamed As String = ""
    Public Overridable Property OrgUnit1 As String
        Get
            Return OrgUnit1_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit1_Renamed = value
        End Set
    End Property
    Private OrgUnit2_Renamed As String = ""
    Public Overridable Property OrgUnit2 As String
        Get
            Return OrgUnit2_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit2_Renamed = value
        End Set
    End Property
    Private OrgUnit3_Renamed As String = ""
    Public Overridable Property OrgUnit3 As String
        Get
            Return OrgUnit3_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit3_Renamed = value
        End Set
    End Property
    Private OrgUnit4_Renamed As String = ""
    Public Overridable Property OrgUnit4 As String
        Get
            Return OrgUnit4_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit4_Renamed = value
        End Set
    End Property
    Private OrgUnit5_Renamed As String = ""
    Public Overridable Property OrgUnit5 As String
        Get
            Return OrgUnit5_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit5_Renamed = value
        End Set
    End Property
    Private OrgUnit6_Renamed As String = ""
    Public Overridable Property OrgUnit6 As String
        Get
            Return OrgUnit6_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit6_Renamed = value
        End Set
    End Property
    Private Custom1_Renamed As String = ""
    Public Overridable Property Custom1 As String
        Get
            Return Custom1_Renamed
        End Get
        Set(ByVal value As String)
            Custom1_Renamed = value
        End Set
    End Property
    Private Custom2_Renamed As String = ""
    Public Overridable Property Custom2 As String
        Get
            Return Custom2_Renamed
        End Get
        Set(ByVal value As String)
            Custom2_Renamed = value
        End Set
    End Property
    Private Custom3_Renamed As String = ""
    Public Overridable Property Custom3 As String
        Get
            Return Custom3_Renamed
        End Get
        Set(ByVal value As String)
            Custom3_Renamed = value
        End Set
    End Property
    Private Custom4_Renamed As String = ""
    Public Overridable Property Custom4 As String
        Get
            Return Custom4_Renamed
        End Get
        Set(ByVal value As String)
            Custom4_Renamed = value
        End Set
    End Property
    Private Custom5_Renamed As String = ""
    Public Overridable Property Custom5 As String
        Get
            Return Custom5_Renamed
        End Get
        Set(ByVal value As String)
            Custom5_Renamed = value
        End Set
    End Property
    Private Custom6_Renamed As String = ""
    Public Overridable Property Custom6 As String
        Get
            Return Custom6_Renamed
        End Get
        Set(ByVal value As String)
            Custom6_Renamed = value
        End Set
    End Property
    Private Custom7_Renamed As String = ""
    Public Overridable Property Custom7 As String
        Get
            Return Custom7_Renamed
        End Get
        Set(ByVal value As String)
            Custom7_Renamed = value
        End Set
    End Property
    Private Custom8_Renamed As String = ""
    Public Overridable Property Custom8 As String
        Get
            Return Custom8_Renamed
        End Get
        Set(ByVal value As String)
            Custom8_Renamed = value
        End Set
    End Property
    Private Custom9_Renamed As String = ""
    Public Overridable Property Custom9 As String
        Get
            Return Custom9_Renamed
        End Get
        Set(ByVal value As String)
            Custom9_Renamed = value
        End Set
    End Property
    Private Custom10_Renamed As String = ""
    Public Overridable Property Custom10 As String
        Get
            Return Custom10_Renamed
        End Get
        Set(ByVal value As String)
            Custom10_Renamed = value
        End Set
    End Property
    Private Custom11_Renamed As String = ""
    Public Overridable Property Custom11 As String
        Get
            Return Custom11_Renamed
        End Get
        Set(ByVal value As String)
            Custom11_Renamed = value
        End Set
    End Property
    Private Custom12_Renamed As String = ""
    Public Overridable Property Custom12 As String
        Get
            Return Custom12_Renamed
        End Get
        Set(ByVal value As String)
            Custom12_Renamed = value
        End Set
    End Property
    Private Custom13_Renamed As String = ""
    Public Overridable Property Custom13 As String
        Get
            Return Custom13_Renamed
        End Get
        Set(ByVal value As String)
            Custom13_Renamed = value
        End Set
    End Property
    Private Custom14_Renamed As String = ""
    Public Overridable Property Custom14 As String
        Get
            Return Custom14_Renamed
        End Get
        Set(ByVal value As String)
            Custom14_Renamed = value
        End Set
    End Property
    Private Custom15_Renamed As String = ""
    Public Overridable Property Custom15 As String
        Get
            Return Custom15_Renamed
        End Get
        Set(ByVal value As String)
            Custom15_Renamed = value
        End Set
    End Property
    Private Custom16_Renamed As String = ""
    Public Overridable Property Custom16 As String
        Get
            Return Custom16_Renamed
        End Get
        Set(ByVal value As String)
            Custom16_Renamed = value
        End Set
    End Property
    Private Custom17_Renamed As String = ""
    Public Overridable Property Custom17 As String
        Get
            Return Custom17_Renamed
        End Get
        Set(ByVal value As String)
            Custom17_Renamed = value
        End Set
    End Property
    Private Custom18_Renamed As String = ""
    Public Overridable Property Custom18 As String
        Get
            Return Custom18_Renamed
        End Get
        Set(ByVal value As String)
            Custom18_Renamed = value
        End Set
    End Property
    Private Custom19_Renamed As String = ""
    Public Overridable Property Custom19 As String
        Get
            Return Custom19_Renamed
        End Get
        Set(ByVal value As String)
            Custom19_Renamed = value
        End Set
    End Property
    Private Custom20_Renamed As String = ""
    Public Overridable Property Custom20 As String
        Get
            Return Custom20_Renamed
        End Get
        Set(ByVal value As String)
            Custom20_Renamed = value
        End Set
    End Property
    Private Custom21_Renamed As String = ""
    Public Overridable Property Custom21 As String
        Get
            Return Custom21_Renamed
        End Get
        Set(ByVal value As String)
            Custom21_Renamed = value
        End Set
    End Property
    Private CtryCode_Renamed As String = ""
    Public Overridable Property CtryCode As String
        Get
            Return CtryCode_Renamed
        End Get
        Set(ByVal value As String)
            CtryCode_Renamed = value
        End Set
    End Property
    Private CashAdvanceAccountCode_Renamed As String = ""
    Public Overridable Property CashAdvanceAccountCode As String
        Get
            Return CashAdvanceAccountCode_Renamed
        End Get
        Set(ByVal value As String)
            CashAdvanceAccountCode_Renamed = value
        End Set
    End Property
    Private CrnKey_Renamed As String = ""
    Public Overridable Property CrnKey As String
        Get
            Return CrnKey_Renamed
        End Get
        Set(ByVal value As String)
            CrnKey_Renamed = value
        End Set
    End Property
    Private CtrySubCode_Renamed As String = ""
    Public Overridable Property CtrySubCode As String
        Get
            Return CtrySubCode_Renamed
        End Get
        Set(ByVal value As String)
            CtrySubCode_Renamed = value
        End Set
    End Property
    Private ExpenseUser_Renamed As String = ""
    Public Overridable Property ExpenseUser As String
        Get
            Return ExpenseUser_Renamed
        End Get
        Set(ByVal value As String)
            ExpenseUser_Renamed = value
        End Set
    End Property
    Private ExpenseApprover_Renamed As String = ""
    Public Overridable Property ExpenseApprover As String
        Get
            Return ExpenseApprover_Renamed
        End Get
        Set(ByVal value As String)
            ExpenseApprover_Renamed = value
        End Set
    End Property
    Private TripUser_Renamed As String = ""
    Public Overridable Property TripUser As String
        Get
            Return TripUser_Renamed
        End Get
        Set(ByVal value As String)
            TripUser_Renamed = value
        End Set
    End Property
    Private InvoiceUser_Renamed As String = ""
    Public Overridable Property InvoiceUser As String
        Get
            Return InvoiceUser_Renamed
        End Get
        Set(ByVal value As String)
            InvoiceUser_Renamed = value
        End Set
    End Property
    Private InvoiceApprover_Renamed As String = ""
    Public Overridable Property InvoiceApprover As String
        Get
            Return InvoiceApprover_Renamed
        End Get
        Set(ByVal value As String)
            InvoiceApprover_Renamed = value
        End Set
    End Property
    Private ExpenseApproverEmployeeID_Renamed As String = ""
    Public Overridable Property ExpenseApproverEmployeeID As String
        Get
            Return ExpenseApproverEmployeeID_Renamed
        End Get
        Set(ByVal value As String)
            ExpenseApproverEmployeeID_Renamed = value
        End Set
    End Property
    Private IsTestEmp_Renamed As String = ""
    Public Overridable Property IsTestEmp As String
        Get
            Return IsTestEmp_Renamed
        End Get
        Set(ByVal value As String)
            IsTestEmp_Renamed = value
        End Set
    End Property
    Private privatedefxmlns As String
    Public Property defxmlns() As String
        Get
            Return privatedefxmlns
        End Get
        Set(ByVal value As String)
            privatedefxmlns = value
        End Set
    End Property

    Public Shared Function getUser(ByVal uri As String, ByVal token As String) As UserProfile

        Dim responses As HttpWebResponse = ManageUsers.HttpWrapper.MakeHttpTokenRequest(uri, "GET", Nothing, token)


        Return getResponseList(responses)

    End Function

    Private Shared Function getResponseList(ByVal response As HttpWebResponse) As UserProfile

        ' Generate a string from the response
        Dim xml As String = Utilities.getStringFromStream(response.GetResponseStream())

        ' Parse the xml into a list of reorts

        If (xml = "") Then
            Return Nothing
        End If
        Dim xmlReader As XmlReader = xmlReader.Create(New StringReader(xml))
        Dim RespOut As UserProfile = parseUser(xmlReader)

        Return RespOut

    End Function

    Private Shared Function parseUser(ByVal xmlReader As XmlReader) As UserProfile

        Dim profileUser As UserProfile = Nothing

        Do While xmlReader.Read()
            Select Case xmlReader.NodeType
                Case XmlNodeType.Element ' The node is an element.
                    If xmlReader.Name.Equals("UserProfile") AndAlso xmlReader.IsStartElement() Then
                        profileUser = New UserProfile
                        profileUser.defxmlns = xmlReader.NamespaceURI.ToString
                    ElseIf xmlReader.Name.Equals("LoginId") Then
                        xmlReader.Read()
                        profileUser.LoginID = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("CrnKey") Then
                        xmlReader.Read()
                        profileUser.CrnKey = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("FirstName") Then
                        xmlReader.Read()
                        profileUser.FirstName = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("LastName") Then
                        xmlReader.Read()
                        profileUser.LastName = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Mi") Then
                        xmlReader.Read()
                        profileUser.Mi = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("EmailAddress") Then
                        xmlReader.Read()
                        profileUser.EmailAddress = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("EmpId") Then
                        xmlReader.Read()
                        profileUser.EmpID = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Active") Then
                        xmlReader.Read()
                        profileUser.Active = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("OrgUnit1") Then
                        xmlReader.Read()
                        profileUser.OrgUnit1 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("OrgUnit2") Then
                        xmlReader.Read()
                        profileUser.OrgUnit2 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("OrgUnit3") Then
                        xmlReader.Read()
                        profileUser.OrgUnit3 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("OrgUnit4") Then
                        xmlReader.Read()
                        profileUser.OrgUnit4 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("OrgUnit5") Then
                        xmlReader.Read()
                        profileUser.OrgUnit5 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("OrgUnit6") Then
                        xmlReader.Read()
                        profileUser.OrgUnit6 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom1") Then
                        xmlReader.Read()
                        profileUser.Custom1 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom2") Then
                        xmlReader.Read()
                        profileUser.Custom2 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom3") Then
                        xmlReader.Read()
                        profileUser.Custom3 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom4") Then
                        xmlReader.Read()
                        profileUser.Custom4 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom5") Then
                        xmlReader.Read()
                        profileUser.Custom5 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom6") Then
                        xmlReader.Read()
                        profileUser.Custom6 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom7") Then
                        xmlReader.Read()
                        profileUser.Custom7 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom8") Then
                        xmlReader.Read()
                        profileUser.Custom8 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom9") Then
                        xmlReader.Read()
                        profileUser.Custom9 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom10") Then
                        xmlReader.Read()
                        profileUser.Custom10 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom11") Then
                        xmlReader.Read()
                        profileUser.Custom11 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom12") Then
                        xmlReader.Read()
                        profileUser.Custom12 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom13") Then
                        xmlReader.Read()
                        profileUser.Custom13 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom14") Then
                        xmlReader.Read()
                        profileUser.Custom14 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom15") Then
                        xmlReader.Read()
                        profileUser.Custom15 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom16") Then
                        xmlReader.Read()
                        profileUser.Custom16 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom17") Then
                        xmlReader.Read()
                        profileUser.Custom17 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom18") Then
                        xmlReader.Read()
                        profileUser.Custom18 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom19") Then
                        xmlReader.Read()
                        profileUser.Custom19 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom20") Then
                        xmlReader.Read()
                        profileUser.Custom20 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("Custom21") Then
                        xmlReader.Read()
                        profileUser.Custom21 = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("LedgerName") Then
                        xmlReader.Read()
                        profileUser.LedgerKey = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("LocaleName") Then
                        xmlReader.Read()
                        profileUser.LocaleName = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("CtryCode") Then
                        xmlReader.Read()
                        profileUser.CtryCode = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("CtrySubCode") Then
                        xmlReader.Read()
                        profileUser.CtrySubCode = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("ExpenseUser") Then
                        xmlReader.Read()
                        profileUser.ExpenseUser = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("ExpenseApprover") Then
                        xmlReader.Read()
                        profileUser.ExpenseApprover = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("TripUser") Then
                        xmlReader.Read()
                        profileUser.TripUser = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("InvoiceUser") Then
                        xmlReader.Read()
                        profileUser.InvoiceUser = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("InvoiceApprover") Then
                        xmlReader.Read()
                        profileUser.InvoiceApprover = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("ExpenseApproverEmployeeID") Then
                        xmlReader.Read()
                        profileUser.ExpenseApproverEmployeeID = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("IsTestEmp") Then
                        xmlReader.Read()
                        profileUser.IsTestEmp = xmlReader.Value
                    ElseIf xmlReader.Name.Equals("CashAdvanceAccountCode") Then
                        xmlReader.Read()
                        profileUser.CashAdvanceAccountCode = xmlReader.Value
                    End If
                Case Else
            End Select
        Loop
        Return profileUser

    End Function

End Class
