﻿Module Module1

    Sub Main()

        Dim user As String = "LoginId"
        Dim password As String = "Password"
        Dim key As String = "Consumer Key"
        Dim URL As String = "https://www.concursolutions.com/net2/oauth2/accesstoken.ashx"

        Dim Mgr As New Manager(key, user, password, URL)

        ''Display Purposes
        Console.WriteLine("Authorization Token")
        Console.WriteLine(Mgr.tokens.Token.ToString)

        Console.ReadLine()

    End Sub

End Module
