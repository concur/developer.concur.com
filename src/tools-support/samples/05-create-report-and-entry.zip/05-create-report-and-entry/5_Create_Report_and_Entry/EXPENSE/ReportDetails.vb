﻿Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Linq
Imports System.Net
Imports System.Text
Imports System.Xml

Public Class ReportDetails

    Private AmountDueCompanyCard_Renamed As String = ""
    Public Overridable Property AmountDueCompanyCard As String
        Get
            Return AmountDueCompanyCard_Renamed
        End Get
        Set(ByVal value As String)
            AmountDueCompanyCard_Renamed = value
        End Set
    End Property
    Private AmountDueEmployee_Renamed As String = ""
    Public Overridable Property AmountDueEmployee As String
        Get
            Return AmountDueEmployee_Renamed
        End Get
        Set(ByVal value As String)
            AmountDueEmployee_Renamed = value
        End Set
    End Property
    Private ApsKey_Renamed As String = ""
    Public Overridable Property ApsKey As String
        Get
            Return ApsKey_Renamed
        End Get
        Set(ByVal value As String)
            ApsKey_Renamed = value
        End Set
    End Property
    Private CrnCode_Renamed As String = ""
    Public Overridable Property CrnCode As String
        Get
            Return CrnCode_Renamed
        End Get
        Set(ByVal value As String)
            CrnCode_Renamed = value
        End Set
    End Property
    Private EntryCount_Renamed As String = ""
    Public Overridable Property EntryCount As String
        Get
            Return EntryCount_Renamed
        End Get
        Set(ByVal value As String)
            EntryCount_Renamed = value
        End Set
    End Property
    Private EverSentBack_Renamed As String = ""
    Public Overridable Property EverSentBack As String
        Get
            Return EverSentBack_Renamed
        End Get
        Set(ByVal value As String)
            EverSentBack_Renamed = value
        End Set
    End Property
    Private ExpenseEntriesUrl_Renamed As String = ""
    Public Overridable Property ExpenseEntriesUrl As String
        Get
            Return ExpenseEntriesUrl_Renamed
        End Get
        Set(ByVal value As String)
            ExpenseEntriesUrl_Renamed = value
        End Set
    End Property
    Private HasException_Renamed As String = ""
    Public Overridable Property HasException As String
        Get
            Return HasException_Renamed
        End Get
        Set(ByVal value As String)
            HasException_Renamed = value
        End Set
    End Property
    Private OrgUnit1_Renamed As String = ""
    Public Overridable Property OrgUnit1 As String
        Get
            Return OrgUnit1_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit1_Renamed = value
        End Set
    End Property
    Private OrgUnit2_Renamed As String = ""
    Public Overridable Property OrgUnit2 As String
        Get
            Return OrgUnit2_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit2_Renamed = value
        End Set
    End Property
    Private OrgUnit3_Renamed As String = ""
    Public Overridable Property OrgUnit3 As String
        Get
            Return OrgUnit3_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit3_Renamed = value
        End Set
    End Property
    Private OrgUnit4_Renamed As String = ""
    Public Overridable Property OrgUnit4 As String
        Get
            Return OrgUnit4_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit4_Renamed = value
        End Set
    End Property
    Private OrgUnit5_Renamed As String = ""
    Public Overridable Property OrgUnit5 As String
        Get
            Return OrgUnit5_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit5_Renamed = value
        End Set
    End Property
    Private OrgUnit6_Renamed As String = ""
    Public Overridable Property OrgUnit6 As String
        Get
            Return OrgUnit6_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit6_Renamed = value
        End Set
    End Property
    Private PersonalExpenses_Renamed As String = ""
    Public Overridable Property PersonalExpenses As String
        Get
            Return PersonalExpenses_Renamed
        End Get
        Set(ByVal value As String)
            PersonalExpenses_Renamed = value
        End Set
    End Property
    Private ReportTotal_Renamed As String = ""
    Public Overridable Property ReportTotal As String
        Get
            Return ReportTotal_Renamed
        End Get
        Set(ByVal value As String)
            ReportTotal_Renamed = value
        End Set
    End Property
    Private TotalApprovedAmount_Renamed As String = ""
    Public Overridable Property TotalApprovedAmount As String
        Get
            Return TotalApprovedAmount_Renamed
        End Get
        Set(ByVal value As String)
            TotalApprovedAmount_Renamed = value
        End Set
    End Property
    Private TotalClaimedAmount_Renamed As String = ""
    Public Overridable Property TotalClaimedAmount As String
        Get
            Return TotalClaimedAmount_Renamed
        End Get
        Set(ByVal value As String)
            TotalClaimedAmount_Renamed = value
        End Set
    End Property
    Private ReportId_Renamed As String = ""
    Public Overridable Property ReportId As String
        Get
            Return ReportId_Renamed
        End Get
        Set(ByVal value As String)
            ReportId_Renamed = value
        End Set
    End Property
    Private ReportName_Renamed As String = ""
    Public Overridable Property ReportName As String
        Get
            Return ReportName_Renamed
        End Get
        Set(ByVal value As String)
            ReportName_Renamed = value
        End Set
    End Property
    Private Purpose_Renamed As String = ""
    Public Overridable Property Purpose As String
        Get
            Return Purpose_Renamed
        End Get
        Set(ByVal value As String)
            Purpose_Renamed = value
        End Set
    End Property
    Private ReportDate_Renamed As String = ""
    Public Overridable Property ReportDate As String
        Get
            Return ReportDate_Renamed
        End Get
        Set(ByVal value As String)
            ReportDate_Renamed = value
        End Set
    End Property
    Private EmployeeName_Renamed As String = ""
    Public Overridable Property EmployeeName As String
        Get
            Return EmployeeName_Renamed
        End Get
        Set(ByVal value As String)
            EmployeeName_Renamed = value
        End Set
    End Property
    Private ApvStatusName_Renamed As String = ""
    Public Overridable Property ApvStatusName As String
        Get
            Return ApvStatusName_Renamed
        End Get
        Set(ByVal value As String)
            ApvStatusName_Renamed = value
        End Set
    End Property
    Private PayStatusName_Renamed As String = ""
    Public Overridable Property PayStatusName As String
        Get
            Return PayStatusName_Renamed
        End Get
        Set(ByVal value As String)
            PayStatusName_Renamed = value
        End Set
    End Property
    Private LedgerName_Renamed As String = ""
    Public Overridable Property LedgerName As String
        Get
            Return LedgerName_Renamed
        End Get
        Set(ByVal value As String)
            LedgerName_Renamed = value
        End Set
    End Property
    Private Custom1_Renamed As String = ""
    Public Overridable Property Custom1 As String
        Get
            Return Custom1_Renamed
        End Get
        Set(ByVal value As String)
            Custom1_Renamed = value
        End Set
    End Property
    Private Custom2_Renamed As String = ""
    Public Overridable Property Custom2 As String
        Get
            Return Custom2_Renamed
        End Get
        Set(ByVal value As String)
            Custom2_Renamed = value
        End Set
    End Property
    Private Custom3_Renamed As String = ""
    Public Overridable Property Custom3 As String
        Get
            Return Custom3_Renamed
        End Get
        Set(ByVal value As String)
            Custom3_Renamed = value
        End Set
    End Property
    Private Custom4_Renamed As String = ""
    Public Overridable Property Custom4 As String
        Get
            Return Custom4_Renamed
        End Get
        Set(ByVal value As String)
            Custom4_Renamed = value
        End Set
    End Property
    Private Custom5_Renamed As String = ""
    Public Overridable Property Custom5 As String
        Get
            Return Custom5_Renamed
        End Get
        Set(ByVal value As String)
            Custom5_Renamed = value
        End Set
    End Property
    Private Custom6_Renamed As String = ""
    Public Overridable Property Custom6 As String
        Get
            Return Custom6_Renamed
        End Get
        Set(ByVal value As String)
            Custom6_Renamed = value
        End Set
    End Property
    Private Custom7_Renamed As String = ""
    Public Overridable Property Custom7 As String
        Get
            Return Custom7_Renamed
        End Get
        Set(ByVal value As String)
            Custom7_Renamed = value
        End Set
    End Property
    Private Custom8_Renamed As String = ""
    Public Overridable Property Custom8 As String
        Get
            Return Custom8_Renamed
        End Get
        Set(ByVal value As String)
            Custom8_Renamed = value
        End Set
    End Property
    Private Custom9_Renamed As String = ""
    Public Overridable Property Custom9 As String
        Get
            Return Custom9_Renamed
        End Get
        Set(ByVal value As String)
            Custom9_Renamed = value
        End Set
    End Property
    Private Custom10_Renamed As String = ""
    Public Overridable Property Custom10 As String
        Get
            Return Custom10_Renamed
        End Get
        Set(ByVal value As String)
            Custom10_Renamed = value
        End Set
    End Property
    Private Custom11_Renamed As String = ""
    Public Overridable Property Custom11 As String
        Get
            Return Custom11_Renamed
        End Get
        Set(ByVal value As String)
            Custom11_Renamed = value
        End Set
    End Property
    Private Custom12_Renamed As String = ""
    Public Overridable Property Custom12 As String
        Get
            Return Custom12_Renamed
        End Get
        Set(ByVal value As String)
            Custom12_Renamed = value
        End Set
    End Property
    Private Custom13_Renamed As String = ""
    Public Overridable Property Custom13 As String
        Get
            Return Custom13_Renamed
        End Get
        Set(ByVal value As String)
            Custom13_Renamed = value
        End Set
    End Property
    Private Custom14_Renamed As String = ""
    Public Overridable Property Custom14 As String
        Get
            Return Custom14_Renamed
        End Get
        Set(ByVal value As String)
            Custom14_Renamed = value
        End Set
    End Property
    Private Custom15_Renamed As String = ""
    Public Overridable Property Custom15 As String
        Get
            Return Custom15_Renamed
        End Get
        Set(ByVal value As String)
            Custom15_Renamed = value
        End Set
    End Property
    Private Custom16_Renamed As String = ""
    Public Overridable Property Custom16 As String
        Get
            Return Custom16_Renamed
        End Get
        Set(ByVal value As String)
            Custom16_Renamed = value
        End Set
    End Property
    Private Custom17_Renamed As String = ""
    Public Overridable Property Custom17 As String
        Get
            Return Custom17_Renamed
        End Get
        Set(ByVal value As String)
            Custom17_Renamed = value
        End Set
    End Property
    Private Custom18_Renamed As String = ""
    Public Overridable Property Custom18 As String
        Get
            Return Custom18_Renamed
        End Get
        Set(ByVal value As String)
            Custom18_Renamed = value
        End Set
    End Property
    Private Custom19_Renamed As String = ""
    Public Overridable Property Custom19 As String
        Get
            Return Custom19_Renamed
        End Get
        Set(ByVal value As String)
            Custom19_Renamed = value
        End Set
    End Property
    Private Custom20_Renamed As String = ""
    Public Overridable Property Custom20 As String
        Get
            Return Custom20_Renamed
        End Get
        Set(ByVal value As String)
            Custom20_Renamed = value
        End Set
    End Property
    Private privatedefxmlns As String
    Public Property defxmlns() As String
        Get
            Return privatedefxmlns
        End Get
        Set(ByVal value As String)
            privatedefxmlns = value
        End Set
    End Property


    Public Shared Function getReportDetail(ByVal uri As String, ByVal token As String) As ReportDetailList

        ' Send the request
        Dim response As HttpWebResponse = ManageExpense.HttpWrapper.MakeHttpTokenRequest(uri, "GET", "", token)

        ' Return the list of jobs contained within the response
        Return getReportFromResponse(response)

    End Function

    Private Shared Function getReportFromResponse(ByVal response As HttpWebResponse) As ReportDetailList

        ' Generate a string from the response
        Dim xml As String = Utilities.getStringFromStreamtoString(response.GetResponseStream())

        ' Parse the xml into a list of reorts
        Dim ReportsOut As New ReportDetailList()
        If (xml = "") Then
            Return Nothing
        End If
        Dim xmlReader As XmlReader = xmlReader.Create(New StringReader(xml))
        ReportsOut.parseReport(xmlReader)

        Return ReportsOut

    End Function


End Class

Public Class ReportDetailList
    Inherits List(Of ReportDetails)

    Private privatedefxmlns As String
    Public Property defxmlns() As String
        Get
            Return privatedefxmlns
        End Get
        Set(ByVal value As String)
            privatedefxmlns = value
        End Set
    End Property

    Public Sub parseReport(ByVal xmlreader As XmlReader)

        Dim currentReport As ReportDetails = Nothing

        Do While xmlreader.Read()

            If defxmlns = "" Then
                defxmlns = xmlreader.NamespaceURI.ToString
            End If

            Select Case xmlreader.NodeType
                Case XmlNodeType.Element ' The node is an element.
                    If xmlreader.Name.Equals("ReportDetails") AndAlso xmlreader.IsStartElement() Then
                        currentReport = New ReportDetails()
                        currentReport.defxmlns = xmlreader.NamespaceURI.ToString
                    ElseIf xmlreader.Name.Equals("AmountDueCompanyCard") Then
                        xmlreader.Read()
                        currentReport.AmountDueCompanyCard = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("AmountDueEmployee") Then
                        xmlreader.Read()
                        currentReport.AmountDueEmployee = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("ApsKey") Then
                        xmlreader.Read()
                        currentReport.ApsKey = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("CrnCode") Then
                        xmlreader.Read()
                        currentReport.CrnCode = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("EntryCount") Then
                        xmlreader.Read()
                        currentReport.EntryCount = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("EverSentBack") Then
                        xmlreader.Read()
                        currentReport.EverSentBack = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Expense-Entries-Url") Then
                        xmlreader.Read()
                        currentReport.ExpenseEntriesUrl = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("HasException") Then
                        xmlreader.Read()
                        currentReport.HasException = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("OrgUnit1") Then
                        xmlreader.Read()
                        currentReport.OrgUnit1 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("OrgUnit2") Then
                        xmlreader.Read()
                        currentReport.OrgUnit2 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("OrgUnit3") Then
                        xmlreader.Read()
                        currentReport.OrgUnit3 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("OrgUnit4") Then
                        xmlreader.Read()
                        currentReport.OrgUnit4 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("OrgUnit5") Then
                        xmlreader.Read()
                        currentReport.OrgUnit5 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("OrgUnit6") Then
                        xmlreader.Read()
                        currentReport.OrgUnit6 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("PersonalExpenses") Then
                        xmlreader.Read()
                        currentReport.PersonalExpenses = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("ReportTotal") Then
                        xmlreader.Read()
                        currentReport.ReportTotal = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("TotalApprovedAmount") Then
                        xmlreader.Read()
                        currentReport.TotalApprovedAmount = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("TotalClaimedAmount") Then
                        xmlreader.Read()
                        currentReport.TotalClaimedAmount = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("ReportId") Then
                        xmlreader.Read()
                        currentReport.ReportId = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("ReportName") Then
                        xmlreader.Read()
                        currentReport.ReportName = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Purpose") Then
                        xmlreader.Read()
                        currentReport.Purpose = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("ReportDate") Then
                        xmlreader.Read()
                        currentReport.ReportDate = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("EmployeeName") Then
                        xmlreader.Read()
                        currentReport.EmployeeName = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("ApvStatusName") Then
                        xmlreader.Read()
                        currentReport.ApvStatusName = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("PayStatusName") Then
                        xmlreader.Read()
                        currentReport.PayStatusName = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("LedgerName") Then
                        xmlreader.Read()
                        currentReport.LedgerName = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom1") Then
                        xmlreader.Read()
                        currentReport.Custom1 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom2") Then
                        xmlreader.Read()
                        currentReport.Custom2 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom3") Then
                        xmlreader.Read()
                        currentReport.Custom3 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom4") Then
                        xmlreader.Read()
                        currentReport.Custom4 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom5") Then
                        xmlreader.Read()
                        currentReport.Custom5 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom6") Then
                        xmlreader.Read()
                        currentReport.Custom6 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom7") Then
                        xmlreader.Read()
                        currentReport.Custom7 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom8") Then
                        xmlreader.Read()
                        currentReport.Custom8 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom9") Then
                        xmlreader.Read()
                        currentReport.Custom9 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom10") Then
                        xmlreader.Read()
                        currentReport.Custom10 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom11") Then
                        xmlreader.Read()
                        currentReport.Custom11 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom12") Then
                        xmlreader.Read()
                        currentReport.Custom12 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom13") Then
                        xmlreader.Read()
                        currentReport.Custom13 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom14") Then
                        xmlreader.Read()
                        currentReport.Custom14 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom15") Then
                        xmlreader.Read()
                        currentReport.Custom15 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom16") Then
                        xmlreader.Read()
                        currentReport.Custom16 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom17") Then
                        xmlreader.Read()
                        currentReport.Custom17 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom18") Then
                        xmlreader.Read()
                        currentReport.Custom18 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom19") Then
                        xmlreader.Read()
                        currentReport.Custom19 = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Custom20") Then
                        xmlreader.Read()
                        currentReport.Custom20 = xmlreader.Value

                    End If
                Case XmlNodeType.EndElement 'Reached the end of the element.
                    If xmlreader.Name.Equals("ReportDetails") Then
                        If currentReport IsNot Nothing Then
                            Add(currentReport)
                            currentReport = Nothing
                        End If
                    End If
                Case Else
            End Select
        Loop
    End Sub

End Class
