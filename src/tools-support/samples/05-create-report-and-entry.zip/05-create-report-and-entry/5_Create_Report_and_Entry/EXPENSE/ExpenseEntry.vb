﻿Imports System.Xml
Imports System.IO
Imports System.Net

Public Class ExpenseEntry
    Private CrnKey_Renamed As String = ""
    Public Overridable Property CrnKey As String
        Get
            Return CrnKey_Renamed
        End Get
        Set(ByVal value As String)
            CrnKey_Renamed = value
        End Set
    End Property
    Private ExpKey_Renamed As String = ""
    Public Overridable Property ExpKey As String
        Get
            Return ExpKey_Renamed
        End Get
        Set(ByVal value As String)
            ExpKey_Renamed = value
        End Set
    End Property
    Private Description_Renamed As String = ""
    Public Overridable Property Description As String
        Get
            Return Description_Renamed
        End Get
        Set(ByVal value As String)
            Description_Renamed = value
        End Set
    End Property
    Private TransactionDate_Renamed As String = ""
    Public Overridable Property TransactionDate As String
        Get
            Return TransactionDate_Renamed
        End Get
        Set(ByVal value As String)
            TransactionDate_Renamed = value
        End Set
    End Property
    Private TransactionAmount_Renamed As String = ""
    Public Overridable Property TransactionAmount As String
        Get
            Return TransactionAmount_Renamed
        End Get
        Set(ByVal value As String)
            TransactionAmount_Renamed = value
        End Set
    End Property
    Private PostedAmount_Renamed As String = ""
    Public Overridable Property PostedAmount As String
        Get
            Return PostedAmount_Renamed
        End Get
        Set(ByVal value As String)
            PostedAmount_Renamed = value
        End Set
    End Property
    Private Custom1_Renamed As String = ""
    Public Overridable Property Custom1 As String
        Get
            Return Custom1_Renamed
        End Get
        Set(ByVal value As String)
            Custom1_Renamed = value
        End Set
    End Property
    Private Custom2_Renamed As String = ""
    Public Overridable Property Custom2 As String
        Get
            Return Custom2_Renamed
        End Get
        Set(ByVal value As String)
            Custom2_Renamed = value
        End Set
    End Property
    Private Custom3_Renamed As String = ""
    Public Overridable Property Custom3 As String
        Get
            Return Custom3_Renamed
        End Get
        Set(ByVal value As String)
            Custom3_Renamed = value
        End Set
    End Property
    Private Custom4_Renamed As String = ""
    Public Overridable Property Custom4 As String
        Get
            Return Custom4_Renamed
        End Get
        Set(ByVal value As String)
            Custom4_Renamed = value
        End Set
    End Property
    Private Custom5_Renamed As String = ""
    Public Overridable Property Custom5 As String
        Get
            Return Custom5_Renamed
        End Get
        Set(ByVal value As String)
            Custom5_Renamed = value
        End Set
    End Property
    Private Custom6_Renamed As String = ""
    Public Overridable Property Custom6 As String
        Get
            Return Custom6_Renamed
        End Get
        Set(ByVal value As String)
            Custom6_Renamed = value
        End Set
    End Property
    Private Custom7_Renamed As String = ""
    Public Overridable Property Custom7 As String
        Get
            Return Custom7_Renamed
        End Get
        Set(ByVal value As String)
            Custom7_Renamed = value
        End Set
    End Property
    Private Custom8_Renamed As String = ""
    Public Overridable Property Custom8 As String
        Get
            Return Custom8_Renamed
        End Get
        Set(ByVal value As String)
            Custom8_Renamed = value
        End Set
    End Property
    Private Custom9_Renamed As String = ""
    Public Overridable Property Custom9 As String
        Get
            Return Custom9_Renamed
        End Get
        Set(ByVal value As String)
            Custom9_Renamed = value
        End Set
    End Property
    Private Custom10_Renamed As String = ""
    Public Overridable Property Custom10 As String
        Get
            Return Custom10_Renamed
        End Get
        Set(ByVal value As String)
            Custom10_Renamed = value
        End Set
    End Property
    Private Custom11_Renamed As String = ""
    Public Overridable Property Custom11 As String
        Get
            Return Custom11_Renamed
        End Get
        Set(ByVal value As String)
            Custom11_Renamed = value
        End Set
    End Property
    Private Custom12_Renamed As String = ""
    Public Overridable Property Custom12 As String
        Get
            Return Custom12_Renamed
        End Get
        Set(ByVal value As String)
            Custom12_Renamed = value
        End Set
    End Property
    Private Custom13_Renamed As String = ""
    Public Overridable Property Custom13 As String
        Get
            Return Custom13_Renamed
        End Get
        Set(ByVal value As String)
            Custom13_Renamed = value
        End Set
    End Property
    Private Custom14_Renamed As String = ""
    Public Overridable Property Custom14 As String
        Get
            Return Custom14_Renamed
        End Get
        Set(ByVal value As String)
            Custom14_Renamed = value
        End Set
    End Property
    Private Custom15_Renamed As String = ""
    Public Overridable Property Custom15 As String
        Get
            Return Custom15_Renamed
        End Get
        Set(ByVal value As String)
            Custom15_Renamed = value
        End Set
    End Property
    Private Custom16_Renamed As String = ""
    Public Overridable Property Custom16 As String
        Get
            Return Custom16_Renamed
        End Get
        Set(ByVal value As String)
            Custom16_Renamed = value
        End Set
    End Property
    Private Custom17_Renamed As String = ""
    Public Overridable Property Custom17 As String
        Get
            Return Custom17_Renamed
        End Get
        Set(ByVal value As String)
            Custom17_Renamed = value
        End Set
    End Property
    Private Custom18_Renamed As String = ""
    Public Overridable Property Custom18 As String
        Get
            Return Custom18_Renamed
        End Get
        Set(ByVal value As String)
            Custom18_Renamed = value
        End Set
    End Property
    Private Custom19_Renamed As String = ""
    Public Overridable Property Custom19 As String
        Get
            Return Custom19_Renamed
        End Get
        Set(ByVal value As String)
            Custom19_Renamed = value
        End Set
    End Property
    Private Custom20_Renamed As String = ""
    Public Overridable Property Custom20 As String
        Get
            Return Custom20_Renamed
        End Get
        Set(ByVal value As String)
            Custom20_Renamed = value
        End Set
    End Property
    Private Custom21_Renamed As String = ""
    Public Overridable Property Custom21 As String
        Get
            Return Custom21_Renamed
        End Get
        Set(ByVal value As String)
            Custom21_Renamed = value
        End Set
    End Property
    Private Custom22_Renamed As String = ""
    Public Overridable Property Custom22 As String
        Get
            Return Custom22_Renamed
        End Get
        Set(ByVal value As String)
            Custom22_Renamed = value
        End Set
    End Property
    Private Custom23_Renamed As String = ""
    Public Overridable Property Custom23 As String
        Get
            Return Custom23_Renamed
        End Get
        Set(ByVal value As String)
            Custom23_Renamed = value
        End Set
    End Property
    Private Custom24_Renamed As String = ""
    Public Overridable Property Custom24 As String
        Get
            Return Custom24_Renamed
        End Get
        Set(ByVal value As String)
            Custom24_Renamed = value
        End Set
    End Property
    Private Custom25_Renamed As String = ""
    Public Overridable Property Custom25 As String
        Get
            Return Custom25_Renamed
        End Get
        Set(ByVal value As String)
            Custom25_Renamed = value
        End Set
    End Property
    Private Custom26_Renamed As String = ""
    Public Overridable Property Custom26 As String
        Get
            Return Custom26_Renamed
        End Get
        Set(ByVal value As String)
            Custom26_Renamed = value
        End Set
    End Property
    Private Custom27_Renamed As String = ""
    Public Overridable Property Custom27 As String
        Get
            Return Custom27_Renamed
        End Get
        Set(ByVal value As String)
            Custom27_Renamed = value
        End Set
    End Property
    Private Custom28_Renamed As String = ""
    Public Overridable Property Custom28 As String
        Get
            Return Custom28_Renamed
        End Get
        Set(ByVal value As String)
            Custom28_Renamed = value
        End Set
    End Property
    Private Custom29_Renamed As String = ""
    Public Overridable Property Custom29 As String
        Get
            Return Custom29_Renamed
        End Get
        Set(ByVal value As String)
            Custom29_Renamed = value
        End Set
    End Property
    Private Custom30_Renamed As String = ""
    Public Overridable Property Custom30 As String
        Get
            Return Custom30_Renamed
        End Get
        Set(ByVal value As String)
            Custom30_Renamed = value
        End Set
    End Property
    Private Custom31_Renamed As String = ""
    Public Overridable Property Custom31 As String
        Get
            Return Custom31_Renamed
        End Get
        Set(ByVal value As String)
            Custom31_Renamed = value
        End Set
    End Property
    Private Custom32_Renamed As String = ""
    Public Overridable Property Custom32 As String
        Get
            Return Custom32_Renamed
        End Get
        Set(ByVal value As String)
            Custom32_Renamed = value
        End Set
    End Property
    Private Custom33_Renamed As String = ""
    Public Overridable Property Custom33 As String
        Get
            Return Custom33_Renamed
        End Get
        Set(ByVal value As String)
            Custom33_Renamed = value
        End Set
    End Property
    Private Custom34_Renamed As String = ""
    Public Overridable Property Custom34 As String
        Get
            Return Custom34_Renamed
        End Get
        Set(ByVal value As String)
            Custom34_Renamed = value
        End Set
    End Property
    Private Custom35_Renamed As String = ""
    Public Overridable Property Custom35 As String
        Get
            Return Custom35_Renamed
        End Get
        Set(ByVal value As String)
            Custom35_Renamed = value
        End Set
    End Property
    Private Custom36_Renamed As String = ""
    Public Overridable Property Custom36 As String
        Get
            Return Custom36_Renamed
        End Get
        Set(ByVal value As String)
            Custom36_Renamed = value
        End Set
    End Property
    Private Custom37_Renamed As String = ""
    Public Overridable Property Custom37 As String
        Get
            Return Custom37_Renamed
        End Get
        Set(ByVal value As String)
            Custom37_Renamed = value
        End Set
    End Property
    Private Custom38_Renamed As String = ""
    Public Overridable Property Custom38 As String
        Get
            Return Custom38_Renamed
        End Get
        Set(ByVal value As String)
            Custom38_Renamed = value
        End Set
    End Property
    Private Custom39_Renamed As String = ""
    Public Overridable Property Custom39 As String
        Get
            Return Custom39_Renamed
        End Get
        Set(ByVal value As String)
            Custom39_Renamed = value
        End Set
    End Property
    Private Custom40_Renamed As String = ""
    Public Overridable Property Custom40 As String
        Get
            Return Custom40_Renamed
        End Get
        Set(ByVal value As String)
            Custom40_Renamed = value
        End Set
    End Property
    Private OrgUnit1_Renamed As String = ""
    Public Overridable Property OrgUnit1 As String
        Get
            Return OrgUnit1_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit1_Renamed = value
        End Set
    End Property
    Private OrgUnit2_Renamed As String = ""
    Public Overridable Property OrgUnit2 As String
        Get
            Return OrgUnit2_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit2_Renamed = value
        End Set
    End Property
    Private OrgUnit3_Renamed As String = ""
    Public Overridable Property OrgUnit3 As String
        Get
            Return OrgUnit3_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit3_Renamed = value
        End Set
    End Property
    Private OrgUnit4_Renamed As String = ""
    Public Overridable Property OrgUnit4 As String
        Get
            Return OrgUnit4_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit4_Renamed = value
        End Set
    End Property
    Private OrgUnit5_Renamed As String = ""
    Public Overridable Property OrgUnit5 As String
        Get
            Return OrgUnit5_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit5_Renamed = value
        End Set
    End Property
    Private OrgUnit6_Renamed As String = ""
    Public Overridable Property OrgUnit6 As String
        Get
            Return OrgUnit6_Renamed
        End Get
        Set(ByVal value As String)
            OrgUnit6_Renamed = value
        End Set
    End Property
    Private Comment_Renamed As String = ""
    Public Overridable Property Comment As String
        Get
            Return Comment_Renamed
        End Get
        Set(ByVal value As String)
            Comment_Renamed = value
        End Set
    End Property
    Private privatedefxmlns As String
    Public Property defxmlns() As String
        Get
            Return privatedefxmlns
        End Get
        Set(ByVal value As String)
            privatedefxmlns = value
        End Set
    End Property
    Private privateLocationID As String
    Public Property LocationID() As String
        Get
            Return privateLocationID
        End Get
        Set(ByVal value As String)
            privateLocationID = value
        End Set
    End Property
    Private VendorDescription_Renamed As String = ""
    Public Overridable Property VendorDescription As String
        Get
            Return VendorDescription_Renamed
        End Get
        Set(ByVal value As String)
            VendorDescription_Renamed = value
        End Set
    End Property
    Private IsPersonal_Renamed As String = ""
    Public Overridable Property IsPersonal As String
        Get
            Return IsPersonal_Renamed
        End Get
        Set(ByVal value As String)
            IsPersonal_Renamed = value
        End Set
    End Property
    Private ExchangeRate_Renamed As String = ""
    Public Overridable Property ExchangeRate As String
        Get
            Return ExchangeRate_Renamed
        End Get
        Set(ByVal value As String)
            ExchangeRate_Renamed = value
        End Set
    End Property

    Public Shared Function PostExpenseEntry(ByVal uri As String, ByVal expEntry As ExpenseEntry, ByVal token As String) As ExpenseEntryStatus

        Dim xmldata As String = create(expEntry)
        ' Send the request
        Dim response As HttpWebResponse = ManageExpense.HttpWrapper.MakeHttpTokenRequest(uri, "POST", xmldata, token)

        ' Return the response
        Return getReportFromResponse(response)

    End Function

    Private Shared Function getReportFromResponse(ByVal response As HttpWebResponse) As ExpenseEntryStatus

        ' Generate a string from the response
        Dim xml As String = Utilities.getStringFromStream(response.GetResponseStream())

        ' Parse the xml
        Dim RespOut As New ExpenseEntryStatus()
        If (xml = "") Then
            Return Nothing
        End If
        Dim xmlReader As XmlReader = xmlReader.Create(New StringReader(xml))
        RespOut = parseReport(xmlReader)

        Return RespOut

    End Function

    Public Shared Function parseReport(ByVal xmlreader As XmlReader)

        Dim currentReport As ExpenseEntryStatus = Nothing

        Do While xmlreader.Read()

            Select Case xmlreader.NodeType
                Case XmlNodeType.Element ' The node is an element.
                    If xmlreader.Name.Equals("ReportEntryStatusList") AndAlso xmlreader.IsStartElement() Then
                        currentReport = New ExpenseEntryStatus
                    ElseIf xmlreader.Name.Equals("Index") Then
                        xmlreader.Read()
                        currentReport.Index = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Status") Then
                        xmlreader.Read()
                        currentReport.Status = xmlreader.Value
                    ElseIf xmlreader.Name.Equals("Report-Entry-Details-Url") Then
                        xmlreader.Read()
                        currentReport.ReportEntryDetailsUrl = xmlreader.Value
                    End If
                Case Else
            End Select
        Loop

        Return currentReport
    End Function

    Public Shared Function create(ByVal expEntry As ExpenseEntry) As String

        'create xml
        Dim response As New XmlDocument

        Dim root As XmlElement = response.CreateElement("ReportEntries")

        'set attributes
        root.SetAttribute("xmlns", expEntry.defxmlns.ToString)
        response.AppendChild(root)

        Dim ExpData As ExpenseEntry = expEntry
        Dim newelement As XmlElement = UsersSerialize(response, ExpData)
        root.AppendChild(newelement)

        Return response.InnerXml.ToString

    End Function

    Private Shared Function UsersSerialize(ByVal xml As XmlDocument, ByVal data As ExpenseEntry) As XmlElement
        Dim appendelement As XmlElement = xml.CreateElement("Expense")

        append(xml, appendelement, "CrnCode", data.CrnKey)
        append(xml, appendelement, "ExpKey", data.ExpKey)
        append(xml, appendelement, "Description", data.Description)
        append(xml, appendelement, "TransactionDate", data.TransactionDate)
        append(xml, appendelement, "TransactionAmount", data.TransactionAmount)
        append(xml, appendelement, "PostedAmount", data.PostedAmount)
        append(xml, appendelement, "Comment", data.Comment)
        append(xml, appendelement, "IsPersonal", data.IsPersonal)
        append(xml, appendelement, "ExchangeRate", data.ExchangeRate)
        append(xml, appendelement, "OrgUnit1", data.OrgUnit1)
        append(xml, appendelement, "OrgUnit2", data.OrgUnit2)
        append(xml, appendelement, "OrgUnit3", data.OrgUnit3)
        append(xml, appendelement, "OrgUnit4", data.OrgUnit4)
        append(xml, appendelement, "OrgUnit5", data.OrgUnit5)
        append(xml, appendelement, "OrgUnit6", data.OrgUnit6)
        append(xml, appendelement, "Custom1", data.Custom1)
        append(xml, appendelement, "Custom2", data.Custom2)
        append(xml, appendelement, "Custom3", data.Custom3)
        append(xml, appendelement, "Custom4", data.Custom4)
        append(xml, appendelement, "Custom5", data.Custom5)
        append(xml, appendelement, "Custom6", data.Custom6)
        append(xml, appendelement, "Custom7", data.Custom7)
        append(xml, appendelement, "Custom8", data.Custom8)
        append(xml, appendelement, "Custom9", data.Custom9)
        append(xml, appendelement, "Custom10", data.Custom10)
        append(xml, appendelement, "Custom11", data.Custom11)
        append(xml, appendelement, "Custom12", data.Custom12)
        append(xml, appendelement, "Custom13", data.Custom13)
        append(xml, appendelement, "Custom14", data.Custom14)
        append(xml, appendelement, "Custom15", data.Custom15)
        append(xml, appendelement, "Custom16", data.Custom16)
        append(xml, appendelement, "Custom17", data.Custom17)
        append(xml, appendelement, "Custom18", data.Custom18)
        append(xml, appendelement, "Custom19", data.Custom19)
        append(xml, appendelement, "Custom20", data.Custom20)
        append(xml, appendelement, "Custom20", data.Custom20)
        append(xml, appendelement, "Custom21", data.Custom21)
        append(xml, appendelement, "Custom22", data.Custom22)
        append(xml, appendelement, "Custom23", data.Custom23)
        append(xml, appendelement, "Custom24", data.Custom24)
        append(xml, appendelement, "Custom25", data.Custom25)
        append(xml, appendelement, "Custom26", data.Custom26)
        append(xml, appendelement, "Custom27", data.Custom27)
        append(xml, appendelement, "Custom28", data.Custom28)
        append(xml, appendelement, "Custom29", data.Custom29)
        append(xml, appendelement, "Custom30", data.Custom30)
        append(xml, appendelement, "Custom31", data.Custom31)
        append(xml, appendelement, "Custom32", data.Custom32)
        append(xml, appendelement, "Custom33", data.Custom33)
        append(xml, appendelement, "Custom34", data.Custom34)
        append(xml, appendelement, "Custom35", data.Custom35)
        append(xml, appendelement, "Custom36", data.Custom36)
        append(xml, appendelement, "Custom37", data.Custom37)
        append(xml, appendelement, "Custom38", data.Custom38)
        append(xml, appendelement, "Custom39", data.Custom39)
        append(xml, appendelement, "Custom40", data.Custom40)
        append(xml, appendelement, "LocationID", data.LocationID)
        append(xml, appendelement, "VendorDescription", data.VendorDescription)
        Return appendelement

    End Function

    Private Shared Sub append(ByVal xml As XmlDocument, ByVal parent As XmlElement, ByVal tagName As String, ByVal value As String)
        Dim node As XmlElement

        If (value IsNot Nothing AndAlso value IsNot "") Then
            node = xml.CreateElement(tagName)
            node.InnerText = value.ToString()
            parent.AppendChild(node)
        End If
    End Sub
End Class

Public Class ExpenseEntryStatus

    Private Index_Renamed As String = ""
    Public Overridable Property Index As String
        Get
            Return Index_Renamed
        End Get
        Set(ByVal value As String)
            Index_Renamed = value
        End Set
    End Property
    Private Status_Renamed As String = ""
    Public Overridable Property Status As String
        Get
            Return Status_Renamed
        End Get
        Set(ByVal value As String)
            Status_Renamed = value
        End Set
    End Property
    Private ReportEntryDetailsUrl_Renamed As String = ""
    Public Overridable Property ReportEntryDetailsUrl As String
        Get
            Return ReportEntryDetailsUrl_Renamed
        End Get
        Set(ByVal value As String)
            ReportEntryDetailsUrl_Renamed = value
        End Set
    End Property


End Class

